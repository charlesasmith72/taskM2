﻿

//////email Template Variables
var AlertNewForm = '';
var AlertSigned= '';
var AlertAssignedAnalyst ='';
var AlertStatus = '';
var AlertRejectUpdate = '';
var AlertResponseStatus ='';
var AlertAnalysts =function(){
     ///get current response Analysts
           var returnAnalysts ='';
     $('.AssignedAnalystEmail').each(function(Index) {
          returnAnalysts += $(this).attr('href').replace("mailto:", "")+';';
      });
      return returnAnalysts ;
  }
  










$(document).ready(function(){
////Set Alert templates
refreshTemplates();



 

})












////////////////////////
////Save new Alert
function saveAlert(AlertSubject,AlertBody,AlertRecipients,AlertCC){
 
 ////set Recipient
   if(AlertRecipients == undefined ){
      AlertRecipients ="";
   }
////set CC
   if(AlertCC == undefined ){
      AlertCC ="";
   }

    //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'New',
						        listName: "Alerts",
						        valuepairs:  [["Title", AlertSubject],
									          ["Determination_x0020_Form", DeterminationID ],
									          ["Body", AlertBody],
									          ["Recipients", AlertRecipients ],
									          ["CC", AlertCC ],
									          ["Response", ResponseID ],
											   ],
											
						        completefunc: function(xData, Status) {
						      /////////////////////////
							        if(Status == 'success'){	
								        
                                       /// alert('success')
							        }else{
							           

							        
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservices
 
   




};///
////////////////////////////
function refreshTemplates(){
  /////new form alert
 AlertNewForm = {
                    Subject:currentReQNumber+' - Draft Created Successfuly - '+currentSystemDate ,
                    Body:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.'
                     };
/////Signed fom alert
 AlertSigned= {
                    Subject:currentReQNumber+' - Ready for Review - '+currentSystemDate ,
                    Body:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.'
                     };

/////new Assigned Analysts
 AlertAssignedAnalyst = {
                    Subject:currentReQNumber+' - Assigned for Response - '+currentSystemDate ,
                    Body:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.'
                     };


/////new Status Change
 AlertStatus = {
                    Subject:currentReQNumber+' - '+AlertResponseStatus+' - '+currentSystemDate ,
                    ApprovedBody:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.',
                    ReviewBody:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.',
                    RejectionBody:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.'
 
                      };


/////new Alert for rejection Change 
 AlertRejectUpdate = {
                    Subject:currentReQNumber+' - Determination Updates Were Submitted Successfuly - '+currentSystemDate ,
                    Body:'The requiring office is responsible for completing this form. This form is required for requisitions over $3,500.00, where any deliverable meets the FARs definition of Electronic & Information Technology (EIT). A 508 determination form is required for each EIT product or service that is part of this requisition.'
                     };





};
////////////////////////////////////////////////////
var AlertTabel = function(){
      
   /////Get List Items
   var foundItemCount =0;
   var AlertItem = '';
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+
                             "<FieldRef Name='Body' />"+
                             "<FieldRef Name='Created' />"+ 
                             "<FieldRef Name='Determination_x0020_Form' />"+
                             "<FieldRef Name='Recipients' />"+
                             "<FieldRef Name='CC' />"+                                                          
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: 'Alerts',
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where>'+
													'<Or>'+
														'<Contains>'+
															'<FieldRef Name="Recipients"/>'+
															'<Value Type="Text">'+currentUserProfile.EMail+'</Value>'+
														'</Contains>'+
														'<Contains>'+
															'<FieldRef Name="CC"/>'+
															'<Value Type="Text">'+currentUserProfile.EMail+'</Value>'+
														'</Contains>'+
													'</Or>'+
												'</Where>'+
                                            '<OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                    ///add to found item
                                    foundItemCount +=1;
                                    var AlertTitle = $(this).attr("ows_Title");
                                    var AlertIcon ='';
                                    var AlertReqLink = '508Determination.aspx';
                                    var AlertReqID = $(this).attr("ows_Determination_x0020_Form")
                                                         if(AlertReqID !=undefined ){//refromat ID
                                                          AlertReqID = AlertReqID.substring(0,AlertReqID.indexOf(";")) 
                                                         }
                                      ///Alert formatting
                                         if(AlertTitle != undefined ){
                                                 //set Alert Link 
			                                         if(AlertTitle.indexOf('Draft Created Successfuly')>=0 ){
			                                             AlertReqLink += '?crumb=draft&fid='+AlertReqID ;
			                                         }else{
			                                             AlertReqLink += '?crumb=review&fid='+AlertReqID ;
			                                         }
			                                     //set Alert Icon  
			                                         if(AlertTitle.indexOf('Draft Created Successfuly')>=0 ){
			                                             AlertIcon = '<i class="fa fa-check-square-o" style="color:green;font-size:34px" aria-hidden="true"></i>' ;
			                                          }else if(AlertTitle.indexOf('Ready for Review')>=0 ){
			                                             AlertIcon = '<i class="fa fa-commenting" style="color:#f0ad4e;font-size:34px" aria-hidden="true"></i>' ;
			                                          }else if(AlertTitle.indexOf('Assigned for Response')>=0 ){
			                                             AlertIcon = '<i class="fa fa-user-plus" style="color:#0072bc;font-size:34px" aria-hidden="true"></i>' ;
			                                          }else if(AlertTitle.indexOf('Rejected')>=0 ){
			                                             AlertIcon = '<i class="fa fa-ban" style="color:red;font-size:34px" aria-hidden="true"></i>' ;
			                                          }else if(AlertTitle.indexOf('Determination Updates Were Submitted Successfuly')>=0 ){
			                                             AlertIcon = '<i class="fa fa-reply" style="color:#0072bc;font-size:34px" aria-hidden="true"></i>' ;
			                                          }else if(AlertTitle.indexOf('Approved')>=0 ){
			                                             AlertIcon = '<i class="fa fa-check" style="color:green;font-size:34px" aria-hidden="true"></i>' ;
			                                          }

			                                          	

			                                          	

			                                          	
			                                          			                                             
                                            ///remove date
                                            AlertTitle = $(this).attr("ows_Title").substring(0,$(this).attr("ows_Title").lastIndexOf("-"));
                                            ///add hyperlink
                                            AlertTitle = '<a href="'+AlertReqLink +'">'+AlertIcon+' '+AlertTitle.substring(0,AlertTitle.indexOf("-"))+'</a>'+AlertTitle.substring(AlertTitle.indexOf("-"))

                                          }
                                   //////set Alert 
                                   AlertItem +='<li class="notification">'+
												      '<div class="media">'+
												         ' <div class="media-body">'+
												          '<strong class="notification-title">'+AlertTitle +'</strong>'+
												         // '<p class="notification-desc">'+$(this).attr("ows_Body")+'</p>'+
												
												          '<div class="notification-meta">'+
												            '<small class="timestamp">'+$(this).attr("ows_Created")+'</small>'+
												          '</div>'+
												        '</div>'+
												      '</div>'+
												  '</li>'
												                                  
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 
                    










       var FullTable = '<h3>Recent Notifications (<span style="color:#127864" ><b>'+foundItemCount+'</b></span>)</h3><ul class="notifications" style="overflow-y:auto;max-height:350px">'+
                          AlertItem+
                            '</ul>'
        ///set Button Count Icon
        $('.notifiCount').html(foundItemCount);                    
      return FullTable 
    
}
//////Open Notifications Modal
 function ShowNotificationsModal(){
    
      
 var Modal_ID = 'Upload-Notifications';
 var Modal_Context= 'Notifications'
 var Modal_Title = 'Notifications';
 var Modal_TitleIcon = '<i class="fa fa-bell" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'

 var Modal_Body = Modal_Instructions+AlertTabel();
                
		
 var NewModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog  modal-lg" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
          '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(NewModal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')

   
   }

///////////////////////////////////////////////////
