﻿///set report variables
  var AllItem_Array =[];
  var AllItem_Rows ="";
  var Assignments_Rows ="";
  var MyRequest_Rows ="";
  /////response variables
  var ResponseArray_ID =[];
  var ResponseArray_Status =[];
  var ResponseArray_StatusChartItems =[];
  var ResponseArray_Response =[];
  var ResponseArray_ResponseDate =[];
  var ResponseArray_ResponseTime =[];
  var ResponseArray_EmailID =[];
  var ResponseArray_Created =[];
  var ResponseArray_DisplayCreated =[];
  ///assignment variables
  var ResponseArray_Analysts=[];
  var ResponseArray_AssignButtons=[];
  var ResponseArray_AssignStatus=[];
  
  var AssignedCount =0;
  var UnAssignedCount =0;
  var currentItemReQNumber = function(itemReQ){
     ///set current line item REQ Number
      var returnREQNumber =$('a[AssingnDetID = "'+itemReQ+'"]').attr('AssingnDetREQ');
      return returnREQNumber ;
  }
 ///////custom variable arrays
   var ReportRowCount = 0;
   var ReportArray_Rows =[];
   var ReportArray_REQNO =[];
   var ReportArray_Analysts =[];
   var ReportArray_Status=[];
   var ReportArray_ApprovalReason=[];
   var ReportArray_ApprovalDate =[];
   var ReportArray_RejectionCause=[];
   var ReportArray_RejectionDate =[];
   var ReportArray_Representative=[];
   var ReportArray_RepresentativeEmail=[];
   var ReportArray_RepresentativeOffice =[];
   var ReportArray_RequestDate =[];
   var ReportArray_Amount =[];
   var ReportArray_TimeSpent=[];
   var ReportArray_Description =[];
   var ReportArray_Month =[];
   var ReportArray_Year =[];
   var ReportArray_AmountNumber =[];
   var ReportArray_ApprovalDateNumber =[];
   var ReportArray_RejectionDateNumber =[];
   var ResponseArray_CreatedNumber =[];
   var ReportArray_TimeSpentNumber =[];
   var ReportArray_TimeSpentNumberCustomReport =[];
   var ReportFIlterCount = 0;

 var comparedResults;
 var filterIndexRows = []

$('document').ready(function(){

////get All Request Table
    getAll_RequestData()

});///////////////////
/////////////////////////////////////////////

////// get report data
////get All Responses
  function getAll_ResponseData(){
  getSent_ResponseData()

  //////reset arrays
  ResponseArray_ID =[];
  ResponseArray_Status =[];
  ResponseArray_Response =[];
  ResponseArray_Analysts=[];
  ResponseArray_AssignButtons =[];
  ResponseArray_AssignStatus =[];
  ResponseArray_ResponseDate =[];
  ResponseArray_ResponseTime =[];

  /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                            "<FieldRef Name='ID'/>"+ 
                            "<FieldRef Name='_x0035_08_x0020_Determination'/>"+
                            "<FieldRef Name='Response'/>"+
                            "<FieldRef Name='Approval_x0020_Type'/>"+ 
                            "<FieldRef Name='Rejection_x0020_Reason'/>"+ 
                            "<FieldRef Name='Rejection_x0020_Reason_x0020_Oth'/>"+
                            '<FieldRef Name="Analysts"/>'+
                            '<FieldRef Name="Recent_x0020_Response"/>'+
                            '<FieldRef Name="Display_Created"/>'+                               
                            "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Determination Responses",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          //'<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var Response_ID = $(this).attr("ows_ID");
                                       var Response_DisplayCreated = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1);
                                     var Response_Recent = "";
                                          if($(this).attr("ows_Recent_x0020_Response")!== undefined){
	                                       Response_Recent = $(this).attr("ows_Recent_x0020_Response").substring($(this).attr("ows_Recent_x0020_Response").indexOf('#')+1); 
	                                     };

                                     var ResponseDetermination_ID = "";
	                                     if($(this).attr("ows__x0035_08_x0020_Determination")!== undefined){
	                                       ResponseDetermination_ID = $(this).attr("ows__x0035_08_x0020_Determination").substring($(this).attr("ows__x0035_08_x0020_Determination").indexOf('#')+1); 
	                                     };
	                                   var ResponseDetermination_Status= $(this).attr("ows_Response");
	                                  var ResponseDetermination_ApprovalType= "";
                                           if($(this).attr("ows_Approval_x0020_Type")!== undefined){
	                                       ResponseDetermination_ApprovalType= $(this).attr("ows_Approval_x0020_Type").substring($(this).attr("ows_Approval_x0020_Type").indexOf('#')+1); 
	                                     };
	                                   var ResponseDetermination_RejectionReason= "";
                                           if($(this).attr("ows_Rejection_x0020_Reason")!== undefined){
	                                       ResponseDetermination_RejectionReason= $(this).attr("ows_Rejection_x0020_Reason").substring($(this).attr("ows_Rejection_x0020_Reason").indexOf('#')+1); 
	                                          if(ResponseDetermination_RejectionReason == 'Other'){
	                                           ResponseDetermination_RejectionReason = $(this).attr("ows_Rejection_x0020_Reason_x0020_Oth");
	                                          };
	                                        };
                                      var ResponseDetermination_ResponseStatus="Waiting for Signature";
                                      var ResponseDetermination_Response = "";
                                          if(ResponseDetermination_Status == 'Approve'){
                                             ResponseDetermination_Response = ResponseDetermination_ApprovalType;
                                          }else if(ResponseDetermination_Status == 'Reject'){
                                             ResponseDetermination_Response = ResponseDetermination_RejectionReason;
                                          }
   

                                        ///  set Analyst button
                                     var assignedAnalyst = $(this).attr("ows_Analysts");
                                     var assignedAnalystArry = [];
                                         assignedAnalystArry.push(assignedAnalyst);
                                    var  currentAnalyst = '';
                                    var  currentAnalystStatus = 'Unassigned';
                                         ///set analyst value
                                       if(assignedAnalyst !== undefined){
                                         var Analysts_Array = assignedAnalyst.split(";");
                                            $.each(Analysts_Array , function( index, value ) {
                                                
													   if (index % 2 === 0 && value !== ''){
													     // currentAnalyst  += '<a href="mailto:'+OptionValue+'" >'+OptionValue+'</a>';
											            }else if(value !== ''){
											              var OptionValue = value;
                                                        if(OptionValue.indexOf('#') >= 0){OptionValue = OptionValue.substring(OptionValue.indexOf('#')+1)};
													      currentAnalyst  +=  OptionValue+"; " ;
											              currentAnalystStatus = 'Assigned'
											             }
											  });
                                        };
                                         
                                        
                                        //////////////////////////////////////
                                        /////set Response Email Data
                                         if($.inArray(Response_Recent, ResponseArray_EmailID) !== -1){
                                           var ResponseEmailIndex = ResponseArray_EmailID.indexOf(Response_Recent);  
                                               ResponseArray_ResponseDate.push(ResponseArray_DisplayCreated[ResponseEmailIndex ]); 
                                               var timespentString = date_diff_indays(Response_DisplayCreated,  ResponseArray_DisplayCreated[ResponseEmailIndex ]  ) ;
                                               ReportArray_TimeSpentNumber.push(timespentString ) 
                                               ResponseArray_ResponseTime.push(timespentString +' Day(s)');
                                         }else{
                                               ResponseArray_ResponseDate.push("");
                                               ResponseArray_ResponseTime.push('0 Day(s)');

                                          
                                         }
                                        
                                        
                                        
                                        ////set variables
                                        ResponseArray_ID.push(ResponseDetermination_ID );
                                        ResponseArray_Analysts.push(currentAnalyst);
                                        ResponseArray_Status.push(ResponseDetermination_Status);
                                        ResponseArray_Response.push(ResponseDetermination_Response);


                     
                                    

                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all items
                 
          
}
////////////////////////////////////////////////////////////

////get All Request Table
  function getAll_RequestData(){
  ////get All Responses
   getAll_ResponseData();
  ////empty every table
  $('.Report-Tbody').empty();
  ////get All Responses
 // getAll_ResponseData()
  ////////////
    AllItem_Array =[];
    AllItem_Rows ="";
    Assignments_Rows ="";
    MyRequest_Rows ="";
     ///Reset assigned values
         AssignedCount =0;
         UnAssignedCount =0;

  
   /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                            "<FieldRef Name='ID'/>"+
                            '<FieldRef Name="Requisition_x0020_Number"/>'+
							'<FieldRef Name="Contract_x0020_Number"/>'+
							'<FieldRef Name="Created"/>'+
							'<FieldRef Name="Representative_x0020_Office"/>'+
							'<FieldRef Name="Representative_x0020_Email"/>'+
							'<FieldRef Name="Agency"/>'+
							'<FieldRef Name="Contract_x0020_Amount"/>'+
							'<FieldRef Name="Status"/>'+
							'<FieldRef Name="Display_Created"/>'+
							'<FieldRef Name="Display_x0020_Month"/>'+ 
							'<FieldRef Name="Display_x0020_Year"/>'+  
							'<FieldRef Name="Author"/>'+
							'<FieldRef Name="Description"/>'+	                      
                              "</ViewFields>"

                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "508 Determination",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          //'<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Created" Ascending="FALSE" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var Determination_ID = $(this).attr("ows_ID");
                                     var Determination_REQ = $(this).attr("ows_Requisition_x0020_Number");
                                     var Determination_Contract = $(this).attr("ows_Contract_x0020_Number");
                                     var Determination_Created = $(this).attr("ows_Created");
                                     var Determination_Agency = $(this).attr("ows_Agency");
                                     var Determination_Month = $(this).attr("ows_Display_x0020_Month").substring($(this).attr("ows_Display_x0020_Month").indexOf('#')+1);;
                                     var Determination_Year = $(this).attr("ows_Display_x0020_Year").substring($(this).attr("ows_Display_x0020_Year").indexOf('#')+1);;
                                     var Determination_ResponseResult = "";
                                     var Determination_DateApproved = "";
                                     var Determination_DateReject = "";
                                     var Determination_Time = "";
                                     var Determination_TimeNumberOnly ="";
                                     var Determination_TimeApproved = "";
                                     var Determination_TimeRejected = "";
                                     var Determination_Description= $(this).attr("ows_Description");
                                           if(Determination_Description!== undefined){Determination_Description= Determination_Description.replace(/&#60;/g,"<").replace(/&#62;/g,">")}

                                     var Determination_Author = $(this).attr("ows_Author").substring($(this).attr("ows_Author").indexOf('#')+1)
                                     var Determination_Rep = $(this).attr("ows_Representative_x0020_Email")
                                     var Determination_RepOffice = $(this).attr("ows_Representative_x0020_Office");
                                                                if(Determination_RepOffice !== undefined ){
                                                                  Determination_RepOffice = Determination_RepOffice.substring(Determination_RepOffice.indexOf('#')+1)

                                                                };
							        var Determination_Amount = $(this).attr("ows_Contract_x0020_Amount");
                                         if($(this).attr("ows_Contract_x0020_Amount")!== undefined){
                                         Determination_Amount ='$'+ConvertCurresncy( $(this).attr("ows_Contract_x0020_Amount"));
                                         }
                                         
                                      /// set response values
                                     var Determination_FormStatus = $(this).attr("ows_Status");
                                     var Determination_Status ="Waiting for Signature";
                                     var Determination_Deterimation =""; 
                                     var AssignAnalystButton ="";
                                     var AssignAnalyst ="";
                                     var AssignAnalystStatus ="";

								          if($.inArray(Determination_ID, ResponseArray_ID) !== -1){
								                             var ResponseIndex = ResponseArray_ID.indexOf(Determination_ID);  
								                                 Determination_Deterimation = ResponseArray_Response[ResponseIndex];   
								                                 Determination_Time = ResponseArray_ResponseTime[ResponseIndex];
								                                 Determination_TimeNumberOnly = ReportArray_TimeSpentNumber =[ResponseIndex];
   
								                                 //set Status
								                                 if(ResponseArray_Status[ResponseIndex] == 'Approve' &&  Determination_FormStatus == 'Review'){
								                                    Determination_Status = 'Approved';
								                                    Determination_DateApproved = ResponseArray_ResponseDate[ResponseIndex];
						                                            Determination_DateReject = "";
						                                            Determination_TimeApproved = ResponseArray_ResponseTime[ResponseIndex];
						                                            Determination_TimeRejected = "";

								                                 }else if(ResponseArray_Status[ResponseIndex] == 'Reject' &&  Determination_FormStatus == 'Review'){
								                                    Determination_Status = 'Rejected';
								                                    Determination_DateApproved = "";
						                                            Determination_DateReject = ResponseArray_ResponseDate[ResponseIndex];
						                                            Determination_TimeApproved = "";
						                                            Determination_TimeRejected = ResponseArray_ResponseTime[ResponseIndex];
								                                

								                                 }else {
								                                    Determination_Status = 'Review In Progress';

								                                 };
								                                 //set Analyst
								                                 AssignAnalyst = ResponseArray_Analysts[ResponseIndex].substring(0,ResponseArray_Analysts[ResponseIndex].lastIndexOf(';'));
								                                //set response variable
                                                                 Determination_ResponseResult = ResponseArray_Response[ResponseIndex];
								                                 
                                                                  ////////////////////////    
								                              }
     

							       
							       
							       
							       //////set Report Tables
							             /////5 Day Rule
							             
							             $('#fiveday-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+AssignAnalyst+'</td>'+
							             '<td>'+Determination_RepOffice+' - '+Determination_Rep+'</td>'+
							             '<td>'+Determination_Created+'</td>'+
							             '<td>'+Determination_DateReject+'</td>'+
							             '<td>'+Determination_TimeRejected+'</td>'+
							             '<td>'+Determination_DateApproved+'</td>'+
							             '<td>'+Determination_TimeApproved+'</td>'+
							             '</tr>'
							             );
							             
							             /////Treasury Requsions
							             if(Determination_Agency == "Treasury"){
							              $('#Treasurey-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+Determination_Created+'</td>'+
							             '<td>'+Determination_DateApproved+'</td>'+
							             '<td>'+Determination_Rep+'</td>'+
							             '<td>'+Determination_Amount+'</td>'+
							             '<td>'+Determination_Time+'</td>'+
							             '</tr>'
							             );
							             }
							             

							             /////do28 entry Time Total 
							              $('#EntryTime-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+Determination_TimeApproved+'</td>'+
							             '</tr>'
							             );
							             

							             /////Monthly Amounts
							             $('#MonthlyAmounts-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+Determination_Description+'</td>'+
							             '<td>'+Determination_Month+'</td>'+
							             '<td>'+Determination_Year+'</td>'+
							             '<td>'+Determination_TimeApproved+'</td>'+
							             '<td>'+Determination_Amount+'</td>'+
							             '</tr>'
							             );

							             /////New Submitters Feb 2017- Email
							              $('#NewSubmitter-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+Determination_Created+'</td>'+
							             '<td>'+Determination_RepOffice+'</td>'+
							             '<td>'+Determination_Rep+'</td>'+
							             '</tr>'
							             );

							             /////Approved Requisitions
							             if(Determination_Status == 'Approved'){ 
							             $('#Approved-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+AssignAnalyst+'</td>'+
							             '<td>'+Determination_DateApproved+'</td>'+
							             '<td>'+Determination_ResponseResult+'</td>'+
							             '<td>'+Determination_RepOffice+' - '+Determination_Rep+'</td>'+
							             '</tr>'
							             );
							             }

							             /////Rejection Requisitions
							             if(Determination_Status == 'Rejected'){
							             $('#Rejection-Tbl > .Report-Tbody').append(
							             '<tr>'+
							             '<th scope="row">'+Determination_REQ+'</th>'+
							             '<td>'+AssignAnalyst+'</td>'+
							             '<td>'+Determination_ResponseResult+'</td>'+
							             '<td>'+Determination_DateReject+'</td>'+
							             '<td>'+Determination_RepOffice+' - '+Determination_Rep+'</td>'+
							             '</tr>'
							             );
							             }
							             
							             
							             //////set custom arrays
							              ReportRowCount += 1;
							              ReportArray_Rows.push(ReportRowCount);
							              ReportArray_REQNO.push(Determination_REQ);
										  ReportArray_Analysts.push(AssignAnalyst);
										  ReportArray_Status.push(Determination_Status);
										  ReportArray_ApprovalReason.push(Determination_ResponseResult);
										  ReportArray_ApprovalDate.push(Determination_DateApproved);
										  ReportArray_RejectionCause.push(Determination_ResponseResult);
										  ReportArray_RejectionDate.push(Determination_DateReject);
										  ReportArray_Representative.push(Determination_RepOffice+' - '+Determination_Rep);
										  ReportArray_RepresentativeEmail.push(Determination_Rep);
										  ReportArray_RepresentativeOffice.push(Determination_RepOffice);
										  ReportArray_RequestDate.push(Determination_Created);
										  ReportArray_Amount.push(Determination_Amount);
										  ReportArray_TimeSpent.push(Determination_Time);
										  ReportArray_Description.push(Determination_Description);
										  ReportArray_Month.push(Determination_Month);
										  ReportArray_Year.push(Determination_Year);
										  ///set range arrays
										
										   if(Determination_Amount != undefined){
										  
										       ReportArray_AmountNumber.push($(this).attr("ows_Contract_x0020_Amount"));
										       
										   };
										   
										    if( ReportArray_TimeSpent != undefined){//Display_Created
										       ReportArray_TimeSpentNumberCustomReport.push(Determination_TimeNumberOnly)
										   }
										   
										   if( Determination_Created != undefined){
										  // convert date to string
										  var DateString  = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1);
										      ResponseArray_CreatedNumber.push(DateString)
										   }





										 






							                 
							                 
							                 
							                 
                                      


                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all items
                   
                    ////////set datatable
    $('.report-table').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'excel', 'pdf', 'print'
        ]
    } );
////////set button lables
///Excel
$('.buttons-excel.dt-button').html('<i aria-hidden="true" style="color:green" class="fa fa-file-excel-o" ></i> Excel')
///PDF
$('.buttons-pdf.dt-button').html('<i aria-hidden="true" style="color:#C00000" class="fa fa-file-pdf-o" ></i> PDF')
///Print
$('.buttons-print.dt-button').html('<i aria-hidden="true" style="color:#0072bc" class="fa fa-file-o" ></i> Print')


    $('#report-nav > li').click(function(){
       $(this).toggleClass('active');
       $(this).find('.fa').toggleClass('fa-check')


     });


          
  
  };//////////////////////////
/////////////////////////////////////////////////////////////////////

////get All Responses
  function getSent_ResponseData(){
     ResponseArray_EmailID =[];
	 ResponseArray_Created = [];
	 ResponseArray_DisplayCreated =[];
	
	
  /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                            "<FieldRef Name='ID'/>"+
                            "<FieldRef Name='Created'/>"+
                            "<FieldRef Name='Response'/>"+ 
                            "<FieldRef Name='Display_Created'/>"+               
                            "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Response Log",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          //'<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var ResponseEmail_ID = $(this).attr("ows_ID"); 
                                     var ResponseEmail_Created = $(this).attr("ows_Created");
                                     var ResponseEmail_DisplayCreated = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1);
                                     var ResponseEmail_Response= $(this).attr("ows_Response");
                                         if(ResponseEmail_Response !== undefined ){
                                                          ResponseEmail_Response = ResponseEmail_Response.substring(ResponseEmail_Response.indexOf('#')+1)
                                                         };
                                     ///set Response EMail Array                    
                                     ResponseArray_EmailID.push(ResponseEmail_ID);
                                     ResponseArray_Created.push(ResponseEmail_Created);
                                     ResponseArray_DisplayCreated.push(ResponseEmail_DisplayCreated);

                                    
                                                                     

                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all items
                 
          
}
////////////////////////////////////////////////////////////

function setCustomReport(){

///hide report fiters
$('#customReport-Builder').collapse('hide');
$('#customReport-Wrap').collapse('hide');

///append loading 
$('#Custom-TblWrap').empty().append('<div id="Loading-Container" style="font-size:44px;color:#337ab7"><i aria-hidden="true" class="fa fa-spinner fa-spin fa-3x fa-fw"></i>'+
           '<span class="">Loading Report...</span></div></br>'
)
var ColumnHeaders =["","","","","","","","","","","","","","","",""];
var TableHeaders = '';
var TableRows = '';
///get each column order
$('.report-order').each(function(index){
    var HeaderValue = $(this).val();
    var HeaderText = $(this).children("option").filter(":selected").text();
    var HeaderLabel = $(this).attr('column');

    
     ////set values
       if(HeaderValue == '1'){
       //column 1
       ColumnHeaders.splice(0, 0, HeaderLabel );
       }else if(HeaderValue == '2'){
       //column 2
       ColumnHeaders.splice(1, 0, HeaderLabel );

       }else if(HeaderValue == '3'){
       //column 3
       ColumnHeaders.splice(2, 0, HeaderLabel );
       }else if(HeaderValue == '4'){
       //column 4
       ColumnHeaders.splice(3, 0, HeaderLabel );
       }else if(HeaderValue == '5'){
       //column 5
       ColumnHeaders.splice(4, 0, HeaderLabel );
       }else if(HeaderValue == '6'){
       //column 6
       ColumnHeaders.splice(5, 0, HeaderLabel );
       }else if(HeaderValue == '7'){
       //column 7
       ColumnHeaders.splice(6, 0, HeaderLabel );
       }else if(HeaderValue == '8'){
       //column 8
       ColumnHeaders.splice(7, 0, HeaderLabel );
       }else if(HeaderValue == '9'){
       //column 9
       ColumnHeaders.splice(8, 0, HeaderLabel );
       }else if(HeaderValue == '10'){
       //column 10
       ColumnHeaders.splice(9, 0, HeaderLabel );
       }else if(HeaderValue == '11'){
       //column 11
       ColumnHeaders.splice(10, 0, HeaderLabel );
       } else if(HeaderValue == '12'){
       //column 12
       ColumnHeaders.splice(11, 0, HeaderLabel );
       }else if(HeaderValue == '13'){
       //column 13
       ColumnHeaders.splice(12, 0, HeaderLabel );
       }else if(HeaderValue == '14'){
       //column 14
       ColumnHeaders.splice(13, 0, HeaderLabel );
       }else if(HeaderValue == '15'){
       //column 15
       ColumnHeaders.splice(14, 0, HeaderLabel );
       }else if(HeaderValue == '16'){
       //column 16
       ColumnHeaders.splice(15, 0, HeaderLabel );
       }else if(HeaderValue == '0'){
       //column Other
       ColumnHeaders.splice(16, 0, HeaderLabel );
       }      

})
ColumnHeaders = ColumnHeaders.filter(Boolean);

/////set table values
$.each(ColumnHeaders, function( index, value ) {
////set header
  TableHeaders += '<th scope="col">'+value +'</th>';

});
///set table rows
///set row filters
 filterRows();
 

 

$.each(ReportArray_Rows, function( index, value ) {
var newTableRow = '';
var newTableRowIndex = index;
//////set row data
//if index is not filtered

 if($.inArray(newTableRowIndex , filterIndexRows) !== -1 || filterIndexRows.length ==0){

 

$.each(ColumnHeaders, function( index, value ) {
////set row based each header selected
        if(value == 'Requisition No'){ 
  newTableRow += '<td>'+ReportArray_REQNO[newTableRowIndex]+'</td>';
  }else if(value == 'Analysts'){
    newTableRow += '<td>'+ReportArray_Analysts[newTableRowIndex]+'</td>';
  }else if(value == 'Status'){
    newTableRow += '<td>'+ReportArray_Status[newTableRowIndex]+'</td>';
  }else if(value == 'Approval Reason'){
    newTableRow += '<td>'+ReportArray_ApprovalReason[newTableRowIndex]+'</td>';
  }else if(value == 'Approval Date'){
    newTableRow += '<td>'+ReportArray_ApprovalDate[newTableRowIndex]+'</td>';
  }else if(value == 'Rejection Cause'){
    newTableRow += '<td>'+ReportArray_RejectionCause[newTableRowIndex]+'</td>';
  }else if(value == 'Rejection Date'){
    newTableRow += '<td>'+ReportArray_RejectionDate[newTableRowIndex]+'</td>';
  }else if(value == 'Representative'){
    newTableRow += '<td>'+ReportArray_Representative[newTableRowIndex]+'</td>';
  }else if(value == 'Representative Email'){
    newTableRow += '<td>'+ReportArray_RepresentativeEmail[newTableRowIndex]+'</td>';
  }else if(value == 'Representative Office'){
    newTableRow += '<td>'+ReportArray_RepresentativeOffice[newTableRowIndex]+'</td>';
  }else if(value == 'Request Date'){
    newTableRow += '<td>'+ReportArray_RequestDate[newTableRowIndex]+'</td>';
  }else if(value == 'Amount'){
    newTableRow += '<td>'+ReportArray_Amount[newTableRowIndex]+'</td>';
  }else if(value == 'Time Spent'){
    newTableRow += '<td>'+ReportArray_TimeSpent[newTableRowIndex]+'</td>';
  }else if(value == 'Description'){
    newTableRow += '<td>'+ReportArray_Description[newTableRowIndex]+'</td>';
  }else if(value == 'Month'){
    newTableRow += '<td>'+ReportArray_Month[newTableRowIndex]+'</td>';
  }else if(value == 'Year'){
    newTableRow += '<td>'+ReportArray_Year[newTableRowIndex]+'</td>';
  }

})


////set html
  TableRows += '<tr>'+newTableRow+'</tr>' ;
}///end if in index

});


///append table
$('#Custom-TblWrap').append(
   '<table summary="" id="Custom-Tbl" class="table table-striped table-condensed">'+
            '<thead>'+
            '<tr  >'+
            TableHeaders+
            '</tr>'+
            '</thead>'+
		     '<tbody class="Report-Tbody">'+
		     TableRows +
		     '</tbody>'+ 
             '</table>'


);

                ////////set datatable
    $('#Custom-Tbl').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'excel', 'pdf', 'print'
        ]
    } );
////////set button lables
///Excel
$('.buttons-excel.dt-button').html('<i aria-hidden="true" style="color:green" class="fa fa-file-excel-o" ></i> Excel')
///PDF
$('.buttons-pdf.dt-button').html('<i aria-hidden="true" style="color:#C00000" class="fa fa-file-pdf-o" ></i> PDF')
///Print
$('.buttons-print.dt-button').html('<i aria-hidden="true" style="color:#0072bc" class="fa fa-file-o" ></i> Print')



/////show new report
$('#Loading-Container').remove();
$('#customReport-Wrap').collapse('show');

 





};

//////////////////////////////////////////////
/////set report display order
function setReportColumns(filterID,filterValue){
var selectOrderLI = filterID+'LI'
var selectOrderID = filterID+'Select';
var selectFilterID = filterID+'Filter'

if ($('#'+filterID).is(':checked')) {
   ///show headings
   $('#displayorder-heading').show();
   $('#Custom-FiltersWell').show();
  ////append column order
    $('#Custom-DisplayOrder').append('<li id="'+selectOrderLI+'" class="list-group-item">'+
                                     '<label for="'+selectOrderID +'">'+filterValue+' <span class="sr-only" > Display Order</span></label>'+
                                     '<select column="'+filterValue+'" class="form-control report-order" id="'+selectOrderID +'" aria-required="true">'+
			                         '<option value="0">Select this columns display order</option>'+
						             '<option value="1">Column 1</option>'+
						             '<option value="2">Column 2</option>'+
						             '<option value="3">Column 3</option>'+
						             '<option value="4">Column 4</option>'+
						             '<option value="5">Column 5</option>'+
						             '<option value="6">Column 6</option>'+
						             '<option value="7">Column 7</option>'+
						             '<option value="8">Column 8</option>'+
						             '<option value="9">Column 9</option>'+
						             '<option value="10">Column 10</option>'+
						             '<option value="11">Column 11</option>'+
						             '<option value="12">Column 12</option>'+
						             '<option value="13">Column 13</option>'+
						             '<option value="14">Column 14</option>'+
						             '<option value="15">Column 15</option>'+
						             '<option value="16">Column 16</option>'+
						             '</select>'+
                                     '</li>')
                                     
                                     ////set filters
                                       //setFilter(selectFilterID,filterValue)
                                     
                           }else{
                           ///remove checkbox
                            $('#'+selectOrderLI).remove();
                            
                            ///remove filter
                           // removeFilterColumn(selectFilterID)
                           
                           }          

};

///////////////////////////////////////////////////////////
////// set filters
function setFilter(inputColumnid,inputColumn,filter_Equals){ 
ReportFIlterCount += 1;
  var filterinputID = inputColumnid+'input'+ReportFIlterCount 
       inputColumnid += ReportFIlterCount;
       //filter_Equals = 'text';
       var inputFilterHtml = '<div class="form-group col-lg-3">'+
                '<label for="'+filterinputID +'">'+inputColumn+'</label>'+
			    '<input  disabled="disabled" value="'+inputColumn+'"  style="width:100%" type="text" class="form-control " id="'+filterinputID+'" placeholder="'+inputColumn+'" />'+
			    '</div>'
       var filterOptions = '';
       var filterInputHtml = ''
       ////set comparisons
       if(filter_Equals == 'text'){
         //set filter options
         filter_Equals = '<option>Equals</option>'+
						'<option>Not Equals</option>'
						//'<option>Less Than</option>'+
						//'<option>Greater Than</option>'+
						//'<option>Less Than Or Equal</option>'+
						//'<option>Greater Than Or Equal</option>'  
	     filterInputHtml = '<label for="'+filterinputID +'txt">Value</label>'+
			    '<input    style="width:100%" type="text" class="form-control " id="'+filterinputID+'txt" placeholder="Value to Compare" />'					     
       }else if(filter_Equals == 'date' || filter_Equals == 'amount'){
         //set filter options
         filter_Equals = '<option>Equals</option>'+
						'<option>Not Equals</option>'+
						'<option>Less Than</option>'+
						'<option>Greater Than</option>'+
						'<option>Less Than Or Equal</option>'+
						'<option>Greater Than Or Equal</option>'  
	     filterInputHtml = '<label for="'+filterinputID +'txt">Value</label>'+
			    '<input    style="width:100%" type="text" class="form-control " id="'+filterinputID+'txt" placeholder="Value to Compare" />'				
       
       };
///create new list item
$('#Custom-Filter').append('<li id="'+inputColumnid+'" rowid="'+filterinputID+'" class="list-group-item filter-row"  ></li>')
////add column readonly input
 $('#'+inputColumnid ).append('<div class="form-inline row">'+
                  inputFilterHtml+
			     '<div class="form-group col-lg-4">'+
                '<label for="'+filterinputID+'Select">Comparison</label>'+
			    '<select   style="width:100%" type="text" class="form-control " id="'+filterinputID+'Select" placeholder="" >'+
			   filter_Equals+
			    '</select>'+
			    '</div>'+
			     '<div class="form-group col-lg-4">'+
                     filterInputHtml  +
			    '</div>'+
			    // '<div class="form-group col-lg-3">'+
                //'<label for="'+filterinputID+'Select2">And / Or</label>'+
			    //'<select   style="width:100%" type="text" class="form-control " id="'+filterinputID+'Select2" placeholder="" >'+
			    //'<option>And</option>'+
			   // '<option>Or</option>'+
			   // '</select>'+
			    // '</div>'+
			     '</div>'+
			    '<br/><button type="button" onclick="removeFilterColumn('+"'"+inputColumnid+"'"+')" class="btn btn-danger btn-xs ">Remove Filter</button>'
			    )
    

}

////////////////////////////
////remove filter
function removeFilterColumn(inputColumnid){
 ///remove filter
 $('#'+inputColumnid).remove();

}

//////////////////////////
/////compare values
function compareValues(compareInput,comparison,TestValue,reportvalue){
     if(comparison == 'Equals'){
        ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
              
                 if(value == TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })
     }else if(comparison == 'Not Equals'){
         ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
                 if(value != TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })
     
     }else if(comparison == 'Less Than'){
     ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
                 if(Number(value) < TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })
     }else if(comparison == 'Greater Than'){
     ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
                 if(Number(value)> TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })
     }else if(comparison == 'Less Than Or Equal'){
     ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
                 if(Number(value)<= TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })
    
     }else if(comparison == 'Greater Than Or Equal'){
     ///check each value for indexs
         $.each(reportvalue, function( index, value ) {
              /////comapre values
                 if(Number(value)>= TestValue){
                    filterIndexRows.push(index);
                 }         
              //////////////
           })

     
     }////////end if statement



  

};
/////////////////////////////////
   /////compare values
function filterRows(){
   filterIndexRows =[];
    ///get each filter row
    $('.filter-row').each(function(){
    ///set row id
       var filterrowID = $(this).attr('rowid');
       var filterrowFilterValue = $('#'+filterrowID).val() 
       var filterrowSelect = $('#'+filterrowID+"Select").val() 
       var filterrowValue = $('#'+filterrowID+"txt").val() 
       

        if(filterrowFilterValue == 'Requisition Number'){ 
              ///get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_REQNO)
                   
            }else if(filterrowFilterValue == 'Analysts'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Analysts)

  }else if(filterrowFilterValue == 'Status'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Status)

  }else if(filterrowFilterValue == 'Approval Reason'){
    //get each index
               compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_ApprovalReason)

  }else if(filterrowFilterValue == 'Approval Date'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_ApprovalDate)

  }else if(filterrowFilterValue == 'Rejection Cause'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_RejectionCause)

  }else if(filterrowFilterValue == 'Rejection Date'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_RejectionDate)

  }else if(filterrowFilterValue == 'Representative'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Representative)

  }else if(filterrowFilterValue == 'Representative Email'){
   //get each index
               compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_RepresentativeEmail)

  }else if(filterrowFilterValue == 'Representative Office'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_RepresentativeOffice)

  }else if(filterrowFilterValue == 'Request Date'){
    //get each index
               compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ResponseArray_CreatedNumber)

  }else if(filterrowFilterValue == 'Amount'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_AmountNumber)

  }else if(filterrowFilterValue == 'Time Spent'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_TimeSpentNumberCustomReport)

  }else if(filterrowFilterValue == 'Description'){
    //get each index
              compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Description)

  }else if(filterrowFilterValue == 'Month'){
   //get each index
             compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Month)

  }else if(filterrowFilterValue == 'Year'){
    //get each index
            compareValues(filterrowFilterValue,filterrowSelect,filterrowValue ,ReportArray_Year)

  }


       



    });
   /////////////////////////
};
///////////
