﻿var form508valid ='Yes'
var DeterminSignature ="Not Signed";
var ResponseID ="";

/////set Details Details defaults 
var DeterminationDetails = {
                         VulcanID:DeterminationID ,
                         Status:'Value',
                         Created:'Value',
                         Analysts:'None Assigned',
                         Response:'Value',
                         ReviewTime:'Value',
                         setValues:function(){
                         ///append values
                         $('.VulcanID-Value').html(this.VulcanID );
                         $('.Status-Value').html(this.Status);
                         $('.Created-Value').html('</br>'+this.Created);
                         $('.Analysts-Value').html(this.Analysts);
                         $('.Response-Value').html(this.Response);
                         $('.ReviewTime-Value').html(this.ReviewTime);
                         $('.status-display').html(this.Status+' '+this.Response).attr('response',this.Response);
                         ///set readonly mode
                         readonly_508(this.Response)
                         }
};
                         
$(document).ready(function(){
Load508Form()

                                                                               
///Get Selectable Office Business Unites
  getBusinessUnitesOptions('#RepresentativeOfficeInput')
 

//set Defaults if new form
if(currentPageCrumb == 'new'||currentPageCrumb === undefined || DeterminationID ===undefined){
 ///hide delete button
     $('.btn-DeleteDraft').hide();
/////set default Office Representative
   //Name
   $('#RepresentativeNameInput').val(currentUserProfile.FirstName+' '+currentUserProfile.LastName)
   //Email
   $('#RepresentativeEmailInput').val(currentUserProfile.EMail)
   
   ///////////set Determination Description text editor
    CKEDITOR.replace( 'RepresentativeDescribeInput' );


/////set default SIgnature Fields
$('#508Signature-Date').val(currentSystemDate);
 //////////////get Determination Responses 
        Load508Form('Done');


}else if( currentPageCrumb == 'draft' && DeterminationID !== undefined){//set Defaults if Draft form
     
    
     /////set default SIgnature Fields
   $('#508Signature-Date').val(currentSystemDate)

     ////////Load Determination Form
     get508FormItems();
     getAttachmentFiles(DeterminationID);
    //// udpdate breadcrumb  
    $('#brumb-current').html('Requisition'+' '+currentReQNumber )
    /////Disable REQ Number
       //$('#RequisitionInput').prop('readOnly', true);
 /////Disable Contract Number 
    //  $('#ContractInput').prop('readOnly', true);
//alert(DeterminSignature )
//////Update Draft Button
     if(DeterminSignature !=="Not Signed" ){
     setReviewHtml()
      
      }else{
         $('.btn-SaveDraft').html('Update Draft').attr('onclick',"saveDraft('Update')");
         
      }
///////////enable upload button
       $('.btn-Upload').prop('disabled', false);

     //////////////get Determination Responses 
        Load508Form('Done');
         //////refresh Permissions
       enableUsers();


}else if( currentPageCrumb == 'review' && DeterminationID !== undefined){//set Defaults if Draft form
       //set ckeditors 
       //CKEDITOR.replace( 'ReviewResponseInput_ApprovalComments' ); 
       //CKEDITOR.replace( 'ReviewResponseInput_RejectionComments' );
      ///////set review tab in navigation
       $('#determination-wizard').append(
      '<li><a id="step4-Link"   role="button" data-toggle="collapse" onclick="$('+"'.form-step'"+').not('+"'#step4'"+').collapse('+"'hide'"+')" href="#step4" aria-expanded="false" aria-controls="step4" ><i aria-hidden="true" class="fa fa-check"></i> Review</a></li>'
      )
    ///enable next button
       $('#step4-next').attr('disabled',false).show();
     ////////Load Determination Form
     get508FormItems();
     getAttachmentFiles(DeterminationID);
    //// udpdate breadcrumb  
    $('#brumb-current').html('Requisition'+' '+currentReQNumber )
    /////Disable REQ Number
       //$('#RequisitionInput').prop('readOnly', true);
 /////Disable Contract Number 
    //  $('#ContractInput').prop('readOnly', true);

//////Update Draft Button
      $('.btn-SaveDraft').html('Update Form').attr('onclick',"saveDraft('review')")

///////////enable upload button
       $('.btn-Upload').prop('disabled', false);
///update Status
      setReviewHtml()

   ///////////show determination options
   $('#Review-FormOptions').show()
   
   //////////////get Determination Responses 
     getDeterminationResponses(function(){
        Load508Form('Done');
     });
   
   
   ////////set Determination Details
   DeterminationDetails.setValues() ;
     //////refresh Permissions
       enableUsers();


}////////////

 

////////////////////////
///Determination wizard
$('#determination-wizard > li').click(function(){
   $('#determination-wizard > li').removeClass('active')
   ///add active class
   $(this).addClass('active');
   
   
   //////Save Draft before continuing
  if( $(this).children('a').attr('id') !== "step1-Link" && DeterminationID == undefined){
   ////confirm save draft
   confirmDraftSave()
   }////End Save Draft before continuing
    
})////////////////////
///////////////////////////
///Tech Standard Checkboxs
///////if parent checkbox is clicked
   $('body').on('click','.TechStandard-cbx',function(){
        //////if checked
        var parentTechCbx = $(this).attr('id')
      if($(this).is(':checked')){
          ////// check all sub check boxes
          $('input[parentcbx="'+parentTechCbx+'"]').prop('checked',true);
      }else{
         ////// un-check all sub check boxes
         $('input[parentcbx="'+parentTechCbx+'"]').prop('checked',false);
      
      }
   
   })
////////////////
///////if provision sub checkbox is clicked
   $('body').on('click','input[parentcbx]',function(){
        //////if checked
        var parentTechCbx = $(this).attr('parentcbx')
    if($(this).is(':checked')){
                    var cbxStatusAll = 'Checked'
			       ///// if all are checked select parent
			       $('input[parentcbx="'+parentTechCbx +'"]').each(function(){
			           ////////check parent 
			           if($(this).is(':checked')){
			           ////// 
			           }else{
			           ///found unchecked set var
			            cbxStatusAll = 'Not Checked'
			           };
			       });
			       ///////////////////////
			        /////check parent becuse all provisions have been checked checkbox
			           if(cbxStatusAll == 'Checked'){
                        $('#'+parentTechCbx).prop('checked',true);
			           }
			           ///////////////////

       }else{
       /////un check parent becuse missing a checked checkbox
        $('#'+parentTechCbx).prop('checked',false);

       }
});
///////////////////////////end Tech Standard Checkboxs

///////
});///End document ready
///
/////// Confirm Draft
function confirmDraftSave(){ 

 var DraftREQNumber =$('#RequisitionInput').val() 
 var Modal_ID = 'Confirm-Modal';
 var Modal_Context= 'Alert'
 var Modal_Title = 'Confirm';
 var Modal_TitleIcon = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>';
 var Modal_Body = '<p>'+
 'A draft version of this form is <b>required</b> to continue. Are you sure you want to save a Draft version of this 508 Determination Form?<p><span class="sr-only">Requision Number </span><b>'+DraftREQNumber+'</b></p>'+
 '</p>'+
 '<button type="button" onclick="saveDraft()" class="btn btn-success btn-sm" >Yes <span class="sr-only">Save</span></button> '+
 '<button type="button" class="btn btn-default btn-sm" onclick="returntoRequest()" data-dismiss="modal">No <span class="sr-only">Do not save</span></button>'
                
		
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog modal-sm" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" onclick="returntoRequest()" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(DocPropertiesModal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')
  

};
////////////////////////
////////Save draft
function saveDraft(saveMode){
        
        
    var REQNumber = $('#RequisitionInput').val();
        currentReQNumber = REQNumber;
    var ContractNumber =$("#ContractInput").val();
    var AgencySelected = $("input[name='AgencyOptions']:checked").val();
    var RepName = $('#RepresentativeNameInput').val();
    var RepPhone= $('#RepresentativePhoneInput').val();
    var RepEmail= $('#RepresentativeEmailInput').val();
    var RepOffice = $('#RepresentativeOfficeInput').val();
    var EstAmount = $('#RepresentativeAmountInput').val();
    var DescriptionUsed_Html = CKEDITOR.instances["RepresentativeDescribeInput"].getData() ; 
    var DescriptionUsed = DescriptionUsed_Html.replace(/</g,"&#60;").replace(/>/g,"&#62;") ;
    var currentFormEIT ="No"
    var currentFormEIT_Q1 = ''
	var currentFormEIT_Q2 = ''
	var currentFormEIT_Q3 = ''
      if($('#EITForm-cbx').is(':checked')){//EIT FOrm is active
        currentFormEIT ="Yes"
        currentFormEIT_Q1 = ckVal_Html('EITStandards');
	    currentFormEIT_Q2 = ckVal_Html('EITSource');
	    currentFormEIT_Q3 = ckVal_Html('EITDetermine');
      
      }; 
        

    var DeterminStatus = 'Draft';
    var SigStatus = 'Not Signed'
    
 
   /////set save mode features
    if(saveMode == "New" || saveMode == undefined){
     saveMode ="New"
     
    }else if(saveMode == "Update"){
     validate508Form('1');
     
    }else if(saveMode == "Sign"){
            SigStatus = 'New Signature';
            
		     saveMode ="Update";
		     DeterminStatus = "Review";
		     var DeterminSignatureJSON ='{"Name":"'+$('#508Signature-Name').val()+'", "SEID":"'+$('#508Signature-UserName').val()+'", "Date":"'+$('#508Signature-Date').val()+'"}'
		     DeterminSignature =  DeterminSignatureJSON;
		
    }else if(saveMode == "review"){
    validate508Form('1');
       saveMode ="Update";
	   DeterminStatus = "Review";
	   //////reset Response
	   if(DeterminationDetails.Response == 'Rejected'){
	      resetDeterminationResponse()
	   } 
      //////////////////
    }	   
   /////End set save mode features
   
        if(form508valid !== 'No'){////////Save if form Valid
      
                        //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:DeterminationID ,
						        listName: "508 Determination",
						        valuepairs:  [["Title", "Determination Form"],
						                      ["Requisition_x0020_Number",REQNumber],
											  ["Contract_x0020_Number",ContractNumber ],
											  ["Agency",AgencySelected],
											  ["Representative_x0020_Name",RepName],
											  ["Representative_x0020_Phone",RepPhone],
											  ["Representative_x0020_Email",RepEmail],
											  ["Representative_x0020_Office",RepOffice],
											  ["Contract_x0020_Amount",EstAmount],
											  ["Description",DescriptionUsed ],
										      ["Status",DeterminStatus ],
										      ["Signature",DeterminSignature],
										      ["EIT_x0020_Cert",currentFormEIT],    
											  ["EITStandardQuestions",currentFormEIT_Q1],
											  ["EITSourceQuestion",currentFormEIT_Q2],
											  ["EITDetermineQuestion",currentFormEIT_Q3],
											],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							        //////////End set Save Mode Functions
							        if(saveMode == "New"){///if new
							          var newID = $(xData.responseXML).SPFilterNode("z:row").attr("ows_ID");
							        DeterminationID = newID ;
							        refreshTemplates();
							        ////create new form alert
                                        saveAlert(AlertNewForm.Subject ,AlertNewForm.Body, currentUserProfile.EMail )

							         
							        ////Create Determination Attachment Folder 
                                      createFolder('Determination'+newID)
							          ////close Modal and Redirect form
							      	$('#Confirm-Modal').modal('hide');
								      	window.location = currentPageFileRef+currentPageLocationName+"?crumb=draft&fid="+DeterminationID;
							          }else if(saveMode == "Update" && SigStatus == 'Not Signed'){
							          //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Determination Form updates have been saved.'////Message
										         );
									   //////////////////////////

							          }else if(saveMode == "Update" && SigStatus == 'New Signature'){
							          ///////////create Response place holder
                                          saveResponse('New');
                                      ////create new Signature alert
                                        refreshTemplates()
                                        saveAlert(AlertSigned.Subject ,AlertSigned.Body, currentUserProfile.EMail+';508.requisition.review@irs.gov' )
							           //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Signed!',////Bold Alert
										         'Your Determination Form Signature has been saved.'////Message
										         );
									   //////////////////////////
									   ///update Status
									   setReviewHtml()
									   							          }
							          //////////End set Save Mode Functions
							     /////////////////////////////////////////
							        }else{
							        //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										//////////////////////////////////////////////////         
							        
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservices
   };////////End Save if form Valid


}


//////////////////////////
//////////Confirm Delete Determination Item
function Determination_Delete(){

  ////remove edit modal
 var Modal_ID = 'DeterminationDelete';
 var Modal_Context= 'Alert'
 var Modal_Title = 'Confirm';
 var Modal_TitleIcon = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>';
  ////Modal functions               
 var closethis =    "$('#"+Modal_ID+"').modal('hide')"
 var deletethis =    "Determination_DeleteFunc()"		
 var Modal_Body = '<p>'+
 'Are you sure you want to Delete the Determination Form for Requisition '+currentReQNumber+'? </p>'+
 '</p>'+
 '<button type="button" onclick="'+deletethis+';'+closethis+'" class="btn btn-danger btn-sm" >Yes <span class="sr-only">Delete</span></button> '+
 '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">No <span class="sr-only">Do not Delete</span></button>'
 var ModalHTML = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog modal-sm" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(ModalHTML) ;
  //show Modal
  $('#'+Modal_ID).modal('show')
  


}
///////////////////////////////////
//////////Confirm Delete Determination Item
function Determination_DeleteFunc(){
 
							        ////delete Response items
							        DeleteExtra_DetertminationItems('Determination Responses');
							        ////delete Determination Folder
							        deleteFolder();

  //////Delete SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: "Delete",
						        ID:DeterminationID ,
						        listName: "508 Determination",										
						        completefunc: function(xData, Status) {
							        if(Status == 'success'){	
							        
                                    /////delete redirect
                                    window.location = currentPageFileRef+'SiteAssets/home.aspx'
			                       
		        }else{
		              //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error Deleting your files.'////Message
										         )
										////////////////////////////////////////////////// 
                                                     
		        
		        
		        
		        
		        }//////////////////////////////////////
	          
	        }
	    });
    //////End Delete SPservices
   
 



}
///////////////////////////////////
////////////////////Delete the remaining determination items
function DeleteExtra_DetertminationItems(filelocation){

    
                      $().SPServices.SPUpdateMultipleListItems({
						 listName: filelocation,
						 CAMLQuery: "<Query><Where><Eq><FieldRef Name='_x0035_08_x0020_Determination'/><Value Type='Text'>"+DeterminationID +"</Value></Eq></Where></Query>",
						 batchCmd: "Delete"
						  
						});
	///////////////////////////////////	

}
////////////////////////////////////
////////Load Determination Form
function get508FormItems(){
 /////get List Items
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                              "<FieldRef Name='Requisition_x0020_Number' />"+ 
                              "<FieldRef Name='Contract_x0020_Number' />"+ 
                              "<FieldRef Name='Agency' />"+ 
                              "<FieldRef Name='Representative_x0020_Name' />"+ 
                              "<FieldRef Name='Representative_x0020_Phone' />"+ 
                              "<FieldRef Name='Representative_x0020_Email' />"+
                              "<FieldRef Name='Representative_x0020_Office' />"+ 
                              "<FieldRef Name='Description' />"+
                              "<FieldRef Name='Contract_x0020_Amount' />"+  
                              "<FieldRef Name='Status' />"+
                              "<FieldRef Name='Signature' />"+  
                              "<FieldRef Name='ID' />"+
                              "<FieldRef Name='Display_Created' />"+
                              "<FieldRef Name='Author' />"+
                              "<FieldRef Name='EITStandardQuestions' />"+ 
                              "<FieldRef Name='EITSourceQuestion' />"+ 
                              "<FieldRef Name='EITDetermineQuestion' />"+  
                              "<FieldRef Name='EIT_x0020_Cert' />"+
                              "<FieldRef Name='Author' />"+                                                            
                              "</ViewFields>"

 
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "508 Determination",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where><Contains><FieldRef Name="ID"/><Value Type="Text">'+DeterminationID+'</Value></Contains></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     ///////Set Form variables    
                                     currentReQNumber = $(this).attr("ows_Requisition_x0020_Number")                                                                                                                                                                                                                                                                                                                               
                                     var currentForm_Agency = $(this).attr("ows_Agency");
                                     var currentForm_Author = $(this).attr("ows_Author").substring($(this).attr("ows_Author").indexOf('#')+1)
                                     var currentForm_CTNumber = $(this).attr("ows_Contract_x0020_Number");
                                     var currentForm_FullName = $(this).attr("ows_Representative_x0020_Name");
                                     var currentForm_Phone = $(this).attr("ows_Representative_x0020_Phone");
                                     var currentForm_Email = $(this).attr("ows_Representative_x0020_Email");
                                         ResponseToEmail  = currentForm_Email
                                     var currentForm_Office = $(this).attr("ows_Representative_x0020_Office");
                                      if(currentForm_Office !== undefined ){
                                         currentForm_Office = currentForm_Office.substring(0,currentForm_Office.indexOf(';')) 
                                         }
                                     var currentForm_Amount = $(this).attr("ows_Contract_x0020_Amount");
                                     var currentForm_Description = $(this).attr("ows_Description");
                                         if(currentForm_Description!== undefined){currentForm_Description= currentForm_Description.replace(/&#60;/g,"<").replace(/&#62;/g,">")}
                                     var currentForm_Status = $(this).attr("ows_Status");
                                     var currentForm_Signature = $(this).attr("ows_Signature");
                                         if(currentForm_Signature == undefined ){currentForm_Signature =''}
                                         DeterminSignature = $(this).attr("ows_Signature"); 
                                        // alert($(this).attr("ows_Signature"))
                                     var currentForm_CreatedDisplay = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1)+
                                                                      ' by '+
                                                                      '<a href="mailto:'+$(this).attr("ows_Author").substring($(this).attr("ows_Author").indexOf('#')+1)+'">'+
                                                                      $(this).attr("ows_Author").substring($(this).attr("ows_Author").indexOf('#')+1)+
                                                                      '</a>'
                                     ///////Set Form Fields  
                                     $("input[value='"+currentForm_Agency+"']").prop("checked",true);
                                     $('#RequisitionInput').val(currentReQNumber);
									 $("#ContractInput").val(currentForm_CTNumber);
									 $('#RepresentativeNameInput').val(currentForm_FullName);
									 $('#RepresentativePhoneInput').val(currentForm_Phone);
									 $('#RepresentativeEmailInput').val(currentForm_Email);
									 $('#RepresentativeOfficeInput').val(currentForm_Office);
									 $('#RepresentativeAmountInput').val(currentForm_Amount);
									 $('#RepresentativeDescribeInput').val(currentForm_Description);
									
									/////////set Signature Fields
							
									if(currentForm_Signature.indexOf('{')>= 0){   
									var currentForm_SignatureOBJ = JSON.parse(currentForm_Signature)
									    currentForm_SignatureName = currentForm_SignatureOBJ['Name'];
									    currentForm_SignatureSEID = currentForm_SignatureOBJ['SEID'];
									    currentForm_SignatureDate = currentForm_SignatureOBJ['Date'];
									    
								     $('.SignedUser').html(currentForm_SignatureName);
								        var Sig_Field ="508Signature"
								      ///set User Name
									   $('#'+Sig_Field+'-Name').val(currentForm_SignatureName);
									   ///set Signature
									   $('#'+Sig_Field+'-UserName').val(currentForm_SignatureSEID);
									   ///set Signature Date
									   $('#'+Sig_Field+'-Date').val(currentForm_SignatureDate);
									   ///disable Check box
									    $('#'+Sig_Field+'-cbx').prop('checked', true);
									    $('#'+Sig_Field+'-cbx').addClass('input-enableskip').prop('disabled', true);
									   ///Hide Sign Button
									   $('#'+Sig_Field+'-Btn').hide()
									   ///Set Signature Status
									   $('#'+Sig_Field+'-Status').html('<i class="fa fa-check" aria-hidden="true" ></i> Signed').addClass('badge-success')
									   ///Set Signature Status Screen Reader
									   $('#'+Sig_Field+'-StatusSR').html('Signed by '+currentForm_SignatureName+' on '+currentForm_SignatureDate)
                                     }/////////////////
                                     //////////////////////////////// 
								        
								          /////set Determination details
								           ////Status
								          DeterminationDetails['Status'] = currentForm_Status;
								           ////Created
								           DeterminationDetails['Created'] = currentForm_CreatedDisplay;
								     ////Set EIT Form Fields
								     var currentFormEIT = $(this).attr("ows_EIT_x0020_Cert");
								     var currentFormEIT_Q1 = $(this).attr("ows_EITStandardQuestions");
								     var currentFormEIT_Q2 = $(this).attr("ows_EITSourceQuestion");
								     var currentFormEIT_Q3 = $(this).attr("ows_EITDetermineQuestion");
                                     
                                         if(currentFormEIT == 'Yes'){//If EIT Checked
                                        
                                              //check Check box
                                              $('#EITForm-cbx').prop('checked',true);
                                              //set TextAreas
                                              $('#EITStandards').val(ckVal_ConvertedBack(currentFormEIT_Q1));
                                              $('#EITSource').val(ckVal_ConvertedBack(currentFormEIT_Q2));
                                              $('#EITDetermine').val(ckVal_ConvertedBack(currentFormEIT_Q3));
                                              ///enable EIT
                                                EITCertToggle('#EITForm-cbx');
                                              //
                                         
                                         
                                         }
                                         /////set created b ypermissions
                                         if(currentForm_Author == currentUserProfile.EMail || currentForm_Email == currentUserProfile.EMail  ){
                                          CreatedByPermission ='yes'
                                         }
                                     //////////////////  
                                      
///////////////////////////////////////////   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get List Items
                ///////////set Determination Description text editor
   CKEDITOR.replace( 'RepresentativeDescribeInput' );
         //get emails
         getEmails();

                    



}

///////////////////////////////////////////////////
//////////////Reset Form
 function returntoRequest(){   
			if( $('#step1-Link').attr('aria-expanded') !== 'true'){ 
			   ///hide steps
			  $('.form-step').collapse('hide')
			 ///return to first step
			  $('#step1-Link').click();
			   $('#step1').collapse('show');
			   }
             }
 ///////////////////////////////////////////////////
/////////////////////Vaidate Determination form
function validate508Form(formstep){
     form508valid = 'Yes'
 var ValidationList = "";
 $('#ValidationStep1-errors').empty();
 $('.danger-validation').alert('close'); 
 ////validate Required text inputs
 $("input.vulcan-input[aria-required='true']").not('#RepresentativeAmountInput').each(function(){
      ////validate input
      var thisInput =$(this).attr('id');
      var inputLabel =$("label[for='"+thisInput+"']").html(); if(inputLabel == undefined){inputLabel ='Input'};
	   if($(this).val() == ""){///If Empty
	      $(this).addClass('has-error').attr("aria-invalid", "true");///Update Input  
	      $("label[for='"+thisInput+"']").addClass('has-error');///Update Label
	      ///add to validation list
	      form508valid ='No';
	      ValidationList  += '<li ><a class="alert-link" href="#'+thisInput+'">'+inputLabel.trim()+'</a> This field cannot be blank.</li>';
	   }else{
	     $(this).removeClass('has-error').removeAttr("aria-invalid", "true");///Update Input
	     $("label[for='"+thisInput+"']").removeClass('has-error');///Update Label
	   }
	   /////////////
 });//////End Validate Input
 ////validate Required TextArea
 $("textarea.vulcan-input[aria-required='true']").each(function(){
      ////validate input
      var thisInput =$(this).attr('id');
      var inputLabel =$("label[for='"+thisInput+"']").html(); if(inputLabel == undefined){inputLabel ='Text Area'};
      var thisInputHref = thisInput;
	   if($(this).val() == "" || $(this).val() == " " || $(this).attr('has-cke_editor')== 'yes' ){///If Empty 
		       if($(this).css('visibility') !== 'hidden'){/////if not a custom text editor
		      $(this).addClass('has-error').attr("aria-invalid", "true");///Update Input
		      $("label[for='"+thisInput+"']").addClass('has-error');///Update Label
		       ///add to validation list
		      form508valid ='No';
		      ValidationList  += '<li ><a class="alert-link" href="#'+thisInputHref+'">'+inputLabel.trim()+'</a> This field cannot be blank.</li>';
	   
		     
		        }else if($(this).css('visibility') == 'hidden' && $(this).attr('has-cke_editor')== 'yes' ){/////if  custom text editor is present
		        
                var inputValue = CKEDITOR.instances[thisInput].document.getBody().getText() ;
            
                 ///add to validation list
                 if(inputValue.length <= 0){
                 $('.cke_editor_'+thisInput).addClass('has-error');///Update Input
		        $("label[for='"+thisInput+"']").addClass('has-error');///Update Label 
                thisInputHref = "CKEDITOR.instances['"+thisInput+"'].focus()";
		      form508valid ='No';
		      ValidationList  += '<li ><a class="alert-link"   href="Javascript:'+thisInputHref+'"  >'+inputLabel.trim()+'</a> This field cannot be blank.</li>';
	              }else{
	                 $('.cke_editor_'+thisInput).removeClass('has-error');///Update Input
	                  $("label[for='"+thisInput+"']").removeClass('has-error');///Update Label
	              }
	              ////////////
		        };
		       
	   }else{
	     $(this).removeClass('has-error').removeAttr("aria-invalid", "true");///Update Input
	     $("label[for='"+thisInput+"']").removeClass('has-error');///Update Label
	   }
	   /////////////
 });//////End Validate TextArea

 ////validate Required Select
 $("select.vulcan-input[aria-required='true']").each(function(){
      ////validate input
      var thisInput =$(this).attr('id');
      var inputLabel =$("label[for='"+thisInput+"']").html();if(inputLabel == undefined){inputLabel ='Select'};
	   if($(this).val() == "" || $(this).val() == " "){///If Empty
	      $(this).addClass('has-error').attr("aria-invalid", "true");///Update Input
	      $("label[for='"+thisInput+"']").addClass('has-error');///Update Label
	      ///add to validation list
	      form508valid ='No';
	      ValidationList  += '<li ><a class="alert-link" href="#'+thisInput+'">'+inputLabel.trim()+'</a> This field cannot be blank.</li>';
	   }else{
	     $(this).removeClass('has-error').removeAttr("aria-invalid", "true");///Update Input
	     $("label[for='"+thisInput+"']").removeClass('has-error');///Update Label
	   }
	   /////////////
 });//////End Validate Select
 
 
 ////if under 3500
     //var ContractAmount
	if($('#RepresentativeAmountInput').val() < 3500){ 
	     $('#RepresentativeAmountInput').addClass('has-error').attr("aria-invalid", "true");///Update Input
	      $("label[for='RepresentativeAmountInput']").addClass('has-error');///Update Label
	   form508valid ='No';
	    ValidationList  += '<li id="Error-AmountBellow" ><a class="alert-link" href="#RepresentativeAmountInput">Estimated Contract Amount</a> This field has a value less than $3,500</li>';
	 }else{
	   $('#RepresentativeAmountInput').removeClass('has-error').removeAttr("aria-invalid", "true");///Update Input
	      $("label[for='RepresentativeAmountInput']").removeClass('has-error');///Update Labe
	 }
    
    
   ////Append Validation list for step 1
   if(formstep == '1' && form508valid == 'No'){ 
		   $('#ValidationStep1-errors').append(
				'<div class="alert alert-danger" role="alert"><h4 id="ValidationStep1-errorsH4"><i class="fa fa-exclamation-triangle" aria-hidden="true" ></i><b>Validation Errors</b></h4>'+
		       '<ul>'+
		       ValidationList+
		       '</ul></div>'
		   );
		   ////remove extra label html
		   $('#ValidationStep1-errors > div > ul > li > a > span').remove()
		   ///append alert
		   newAlert('#Form-AlertsStep1','validation','Error!','There were Validation Errors found in the information you submitted. <a class="alert-link" href="#ValidationStep1-errorsH4">View Validation Errors</a>')

	}
   /////////////////////////////////////
    ////Append Validation list for step 3
   if(formstep == '3' && form508valid == 'No'){ 
		   $('#ValidationStep1-errors').append(
				'<div class="alert alert-danger" role="alert"><h4 id="ValidationStep1-errorsH4"><i class="fa fa-exclamation-triangle" aria-hidden="true" ></i><b>Validation Errors</b></h4>'+
		       '<ul>'+
		       ValidationList+
		       '</ul></div>'
		   );
		   
		   ////remove extra label html
		   $('#ValidationStep1-errors > div > ul > li > a > span').remove()
		   ///append alert step 1
		   newAlert('#Form-AlertsStep1','validation','Error!','There were Validation Errors found in the information you submitted. <a class="alert-link" href="#ValidationStep1-errorsH4">View Validation Errors</a>')
           ///append alert step 3
           var onclickfunc= "$('#step1-Link').click()"
		   newAlert('#Form-AlertsStep3','validation','Error!','There were Validation Errors found in the information you submitted on the Determination Request Form. <a role="button" href="#ValidationStep1-errorsH4"  class="alert-link" onclick="'+onclickfunc+'" >View Determination Form</a>')

	}else if(formstep == '3' && form508valid == 'Yes'){ 
	      signSigFields('508Signature');
	   
	}
   /////////////////////////////////////


//////////// 
 }
///////////////////////////
///////re-formate Estimated Contract Amount
function formatContractAmount(inputAmount){
	//// if decimal(remove cents)
	if($(inputAmount).val().indexOf('.') >= 0){
	   $(inputAmount).val($(inputAmount).val().substring(0,$(inputAmount).val().indexOf('.')));   
	};
	////if commas
	if($(inputAmount).val().indexOf(',') >= 0){
	   $(inputAmount).val($(inputAmount).val().replace(/\,/g,''))   
	};
	

}

//////////////////////////////////////////////// 
/////////////Review Response
function reviewResponseToggle(){
   var formResponse =$('#ReviewResponseInput').val();
   ///clear responses
       $('#previousResponse-Contatiner').hide();
       $('.ResponseForm').collapse('hide');
     if(formResponse == 'Approve'){///if Approved
       $('#ApprovalForm').collapse('show')
        ///////////set approval text editor
   // CKEDITOR.instances["ReviewResponseInput_ApprovalComments"].destroy();
   // CKEDITOR.replace( 'ReviewResponseInput_ApprovalComments' );    
     }else if(formResponse == 'Reject'){//if Rejected
       $('#RejectForm').collapse('show');
    ///////////set Rejection text editor
   // CKEDITOR.instances["ReviewResponseInput_RejectionComments"].destroy();
    //CKEDITOR.replace( 'ReviewResponseInput_RejectionComments' );
  
     
     }else if(formResponse == 'On Hold'){//if Rejected
       $('#OnHoldForm').collapse('show')
     
     }else{
      $('#previousResponse-Contatiner').show();
     
     }////////////
////////////



}

////////////////////////////////// 
 //////////////get all items from Applicable Technical Standards
 function getTaechStandards(categoryFIlter){ 
   ///empty standards container
    $('#TechStandards-Contatiner').empty();
     /////get all Applicable Technical Standards
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='Description' />"+ 
                             "<FieldRef Name='Provisions' />"+  
                             "<FieldRef Name='Default_x0020__x0028_always_x002' />"+  
                             "<FieldRef Name='Show_x0020_in_x0020_Determinatio' />"+
                             "<FieldRef Name='Category' />"+   
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Applicable Technical Standards",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      var standard_ID =  $(this).attr("ows_ID");
                                      var standard_Number =  $(this).attr("ows_Title");
                                      var standard_Desc = $(this).attr("ows_Description") ;
                                      var standard_Provision = $(this).attr("ows_Provisions");
                                      var standard_Default = $(this).attr("ows_Default_x0020__x0028_always_x002");
                                      var standard_Showthis = $(this).attr("ows_Show_x0020_in_x0020_Determinatio");   
                                      var disableAttr="";
                                            /////if Always selected
                                            if(standard_Default == 'Yes'){
                                              disableAttr='disabled="disabled" checked="checked"'
                                            }
                                      
                                      
                                    
 
                                      
                                          /////append main checkboxes
                                          $('#TechStandards-Contatiner').append(
                                            '<div >'+
                                            ' <div class="checkbox checkbox-inline checkbox-success">'+
										     '<input '+disableAttr+' stanardNum="'+standard_Number+'" stanardDesc="'+standard_Desc+'" stanardID="'+standard_ID+'"  id="standard-'+standard_ID+'cbx"  class="TechStandard-cbx"  type="checkbox"/>'+
											 '<label for="standard-'+standard_ID+'cbx"  class="checkbox-inline">'+
											 '<b>'+standard_Number+' (<span id="standard-'+standard_ID+'Range"></span>) '+standard_Desc+' <span class="sr-only" >Select All</span><b>'+
											' </label>'+
											'</div>'+
											'<div id="standard-'+standard_ID+'SubContainer" class="form-inline" style="padding-left:20px">'+
											'</div>'+
											'</div>'
                                          );   
                                   
                                     var standard_ProvisionRange ='' ;
                                     var standard_ProvisionRangeFirst = '' ;
                                     var standard_ProvisionRangeLast = '' ;
                                       ///// convert Provisions
                                       var standard_ProvisionArry ='';
                                       if(standard_Provision !== undefined){
                                          standard_ProvisionArry = standard_Provision.split(';');
                                          ///for each found provision
                                               $.each(standard_ProvisionArry,function(index,value){
                                               
                                                 
                                                 /////append sub check boxes
                                                 if(value !== '' && value !== '#'){ 
                                                 var ProValue= '';if(value.indexOf('#') >= 0){
                                                      ProValue = value.substring(value.indexOf('#')+1);
                                                        /// set first found provision
                                                 if(index == 1){
                                                  standard_ProvisionRangeFirst = ProValue;
                                               
                                                 }
                                                     /// set Last found provision
                                                  standard_ProvisionRangeLast = ProValue;
                                                     
                                                 }
                                                 
                                                
                                             
                                  
                                                 
                                                   $('#standard-'+standard_ID+'SubContainer').append(
                                                   '  <div class="checkbox checkbox-inline checkbox-primary">'+
													      '<input '+disableAttr+' id="Provision-'+standard_ID+'cbx'+index +'" value="'+ProValue+'"  parentcbx="standard-'+standard_ID+'cbx"   type="checkbox"/>'+
														  '<label for="Provision-'+standard_ID+'cbx'+index +'">('+ProValue+')</label>'+
														'</div>'

			                                          ) ;///end append
                                                 }
                                                /////////////////////////////////////////////////// 
                                                 
                                            }); ///end for each found provision
                                         
                                       
                                       }////////////////  End convert Provisions
                                          /////append Range
                                    //  alert(standard_ProvisionArry)
                                          $('#standard-'+standard_ID+'Range').html(standard_ProvisionRangeFirst +' - '+ standard_ProvisionRangeLast )
     
                                         
                                          
                                          
                                          
                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all Applicable Technical Standards

 
 }
 ///////////////
 //////////Add other Rejection Reason
 function addRejectionOther(RejectionInput){
     /////empty Container
    $('#OtherRejectionReason-Container').empty();
    ///if other Selected
    if($(RejectionInput+' option:selected').text() == 'Other'){
    var Otherfunc = "$('#RejectResponseInput_Subject').val('"+currentReQNumber+" - '+$(this).val()+' - "+currentSystemDate+"')";
    var RejectionOther_Html ='<div class="form-group" >'+
			      '<label for="ReviewResponseInput_RejectionOther" >Other <span class="sr-only">Rejection</span> Reason <span class="sr-only" >Use this field to created a custom rejection reason.</span></label>'+
						'<input aria-describedby="#RejectionOtherHelp" id="ReviewResponseInput_RejectionOther" onchange="'+Otherfunc+'"   placeholder="Other Rejection Reason" type="text" class="form-control" />'+  
			          '<span id="RejectionOtherHelp" class="help-block">Enter a custom reason for rejecting this request. This field will be used in the email subject.</span>'
			       '</div>';
     ////append Html
      $('#OtherRejectionReason-Container').append(RejectionOther_Html);
      }
 
 }
 //////////////////////set Review Html
 function setReviewHtml(){
 
    ///update Status
		   $('.status-display').html('Review')
		   //////Update Draft Button
          $('.btn-SaveDraft').html('Update Form').attr('onclick',"saveDraft('review')");
          $('.badge.status-display').addClass('status-display-review');

 
 }
 //////////////////////////////////////////////////
 ///////////Save Response
 function saveResponse(saveMode){
  /////set Approval Type
  var SelectedApprovalType = $('#ApprovalTypeInput').val() 
   /////set Response Type
  var SelectedResponse = $('#ReviewResponseInput').val() 
   /////set Rejection Reason
  var SelectedRejection = $('#ReviewResponseInput_Rejecttion').val() 
   /////set Other Reason
  var SelectedOtherRejection = $('#ReviewResponseInput_RejectionOther').val() 
      if(SelectedOtherRejection == undefined){SelectedOtherRejection =''}

    /////set Selected MOD
    var SelectedMOD = $('input[name="MODOptions"]:checked').val()

 /////set Clause Type
 var SelectedClauseTypes = "";
      $('#ClauseTypeInput option:selected').each(function(Index) {
        if(Index == 0){
          SelectedClauseTypes += $(this).val()+';#'+$(this).val() ;
        }else{
          SelectedClauseTypes += ';#'+$(this).val()+';#'+$(this).val() ;
        }
    });
 /////set Selected Requirement Version
    var SelectedRequirementVersion = $('input[name="ProvisionCategory"]:checked').val()

///////////save Tech Standard
     var SelectedTechStandards={"Standard":[]};
     var SelectedTechStandardsObj="";
     ////set STandards
        $('.TechStandard-cbx').each(function(index){
           var StandardID = $(this).attr('stanardid');
           var StandardDesc = $(this).attr('stanarddesc');
           var StandardNum = $(this).attr('stanardnum');
           var StandardChecked = $(this).is(':checked');if(StandardChecked == true ){StandardChecked = 'yes'}else{StandardChecked ='no'};
            SelectedTechStandardsObj = {Number:StandardNum, ID:StandardID, Desc:StandardDesc,checked:StandardChecked,Provision:[]}  ;
            ///////get Provision array
             $('input[parentcbx="standard-'+StandardID+'cbx"]:checked').each(function(index){
               SelectedTechStandardsObj.Provision.push($(this).val());
             });
            ////////push to tech standard  
            SelectedTechStandards.Standard.push(SelectedTechStandardsObj)
        });
        ////// strinagfy to text to save
         var TechStandard_ObjSave = JSON.stringify(SelectedTechStandards);
          
         ///set Response Variables 
             var Response_Comments ="";
             if(saveMode !== "New" && SelectedResponse =='Approve'){
             var Approval_Comments = CKEDITOR.instances["ReviewResponseInput_ApprovalComments"].getData() ; 
              Response_Comments =  Approval_Comments.replace(/</g,"&#60;").replace(/>/g,"&#62;") ;
              }else if(saveMode !== "New" && SelectedResponse =='Reject'){
             var Reject_Comments = CKEDITOR.instances["ReviewResponseInput_RejectionComments"].getData() ; 
              Response_Comments =  Reject_Comments.replace(/</g,"&#60;").replace(/>/g,"&#62;") ;
              }else if(saveMode !== "New" && SelectedResponse =='On Hold'){
             var OnHold_Comments = CKEDITOR.instances["ReviewResponseInput_OnHoldComments"].getData() ; 
              Response_Comments =  OnHold_Comments.replace(/</g,"&#60;").replace(/>/g,"&#62;") ;
              }


         //////////////save Approval Repsonse
           
         ///ReviewResponseInput_ApprovalComments
 
//////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
                                ID:ResponseID ,
						        listName: "Determination Responses",
						        valuepairs:  [["Title", "Response for "+DeterminationID ],
										      ["_x0035_08_x0020_Determination", DeterminationID ],
										      ["Requisition_x0020_MOD", SelectedMOD ],
										      ["Technical_x0020_Standard", TechStandard_ObjSave],
										      ["Response", SelectedResponse ],
										      ["Requirements_x0020_Version",SelectedRequirementVersion ],
										      ["Approval_x0020_Type", SelectedApprovalType ],
										      ["Clause_x0020_Type", SelectedClauseTypes ],
										      ["Rejection_x0020_Reason", SelectedRejection ],
										      ["Rejection_x0020_Reason_x0020_Oth", SelectedOtherRejection ],
										      ["Comments", Response_Comments],
										      ["Recent_x0020_Response", RecentLog ],
											   ],
											
						        completefunc: function(xData, Status) {
						      /////////////////////////
							        if(Status == 'success'){	
								        if(saveMode =='New'){////if save mode is New				        
								          var ResponseID = $(xData.responseXML).SPFilterNode("z:row").attr("ows_ID");
								          }else{
								          ///////Send Response Status chaange alert
								         								          
								          if(SelectedResponse == 'Reject'){
								            ///send Reject Alert
								            AlertResponseStatus = 'Rejected' ;
								            refreshTemplates();
								            saveAlert(AlertStatus.Subject,AlertStatus.RejectionBody,currentUserProfile.EMail+';'+AlertAnalysts());
								          }else if(SelectedResponse == 'Approve'){
								            ///send Reject Alert
								            AlertResponseStatus = 'Approved' ;
								            refreshTemplates();
								            saveAlert(AlertStatus.Subject,AlertStatus.ApprovedBody,currentUserProfile.EMail+';508.requisition.review@irs.gov;'+AlertAnalysts());
								          }else{
								          ///send ready for review Alert
								             AlertResponseStatus = 'Ready for Review' ;
								             refreshTemplates();
								             saveAlert(AlertStatus.Subject,AlertStatus.ReviewBody);

								          }
								          //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Response Form updates have been saved.'////Message
										         );
									   //////////////////////////
									   }

							        }else{
							           //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										//////////////////////////////////////////////////         
							        

							        
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservices
 
   
 
 };
 
 //////////////get Determination Responses 
 function getDeterminationResponses(callback){ 
  //// set text editors
   // CKEDITOR.replace( 'ReviewResponseInput_ApprovalComments' ); 
    //  CKEDITOR.replace( 'ReviewResponseInput_RejectionComments' );

     ////////// get tech standards
   getTaechStandards('Original'); 
 ////get Approval Types
   setSelections('#ApprovalTypeInput','Approval Types');
  ////get Clause Types
   setClauseSelections('#ClauseTypeInput','Clause Types');
     ////get Rejection Reasons
   setSelections('#ReviewResponseInput_Rejecttion','Rejection Reasons');
   

 /////get all Applicable Technical Standards
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='Clause_x0020_Type' />"+
                             "<FieldRef Name='ID' />"+
                             "<FieldRef Name='_x0035_08_x0020_Determination' />"+ 
                             "<FieldRef Name='Technical_x0020_Standard' />"+
                             "<FieldRef Name='Approval_x0020_Type' />"+
                             "<FieldRef Name='Response' />"+
                             "<FieldRef Name='Requisition_x0020_MOD' />"+ 
                             "<FieldRef Name='Requirements_x0020_Version' />"+
                             "<FieldRef Name='Comments' />"+
                             "<FieldRef Name='Display_Created' />"+ 
                              "<FieldRef Name='Rejection_x0020_Reason' />"+   
                               "<FieldRef Name='Rejection_x0020_Reason_x0020_Oth' />"+ 
                               "<FieldRef Name='Recent_x0020_Response' />"+ 
                               "<FieldRef Name='Analysts' />"+                                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items  
                $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Determination Responses",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where><Eq><FieldRef Name="_x0035_08_x0020_Determination"/><Value Type="Text">'+DeterminationID+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                       //////////set response ID
                           ResponseID = $(this).attr("ows_ID");
                      ////set Variables
                      var Response_Created = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1);
                      var Response_Comments = $(this).attr("ows_Comments");
                                if(Response_Comments !== undefined){
                                 Response_Comments =Response_Comments.replace(/&#60;/g,"<").replace(/&#62;/g,">");
                                 }
                       ////set recent Response
                       var Response_Recent = $(this).attr("ows_Recent_x0020_Response");
                             /////set Review Response
					       var Response_Determination = $(this).attr("ows_Response");
					       if(Response_Determination !== undefined){
					           Response_Determination = $(this).attr("ows_Response");
					          //Change value with function trigger
					           $('#ReviewResponseInput').val('');
				             //$('#ReviewResponseInput').val(Response_Determination).change(); 
					        }     
                                 
                                 
                            /////set Approval Type
                            var Response_ApprovalType= $(this).attr("ows_Approval_x0020_Type");
                          
					         if(Response_ApprovalType !== undefined  && Response_Determination == "Approve" ){
					            Response_ApprovalType = $(this).attr("ows_Approval_x0020_Type").substring(0,$(this).attr("ows_Approval_x0020_Type").indexOf(';'))
					           //set value
					           //  alert(Response_ApprovalType)
					            
					        // $('#ApprovalTypeInput').val(Response_ApprovalType).change();
					         }
					         
					          /////set Rejection Type
                            var Response_RejectionType = $(this).attr("ows_Rejection_x0020_Reason");
                            var Response_RejectionTypeOther = $(this).attr("ows_Rejection_x0020_Reason_x0020_Oth");
					         if(Response_RejectionType!== undefined  && Response_Determination == "Reject" ){
					            Response_RejectionType= $(this).attr("ows_Rejection_x0020_Reason").substring(0,$(this).attr("ows_Rejection_x0020_Reason").indexOf(';'))
					           //set value
					       //  $('#ReviewResponseInput_Rejecttion').val(Response_RejectionType)//.change();
					          
					          var Response_RejectionTypeValue = $(this).attr("ows_Rejection_x0020_Reason").substring($(this).attr("ows_Rejection_x0020_Reason").indexOf('#')+1)
					               //if Other Rejection Reason
					               if(Response_RejectionTypeValue == 'Other'&& Response_RejectionTypeOther !== undefined){
					               
					                   $('#ReviewResponseInput_RejectionOther').val(Response_RejectionTypeOther)
					               }
					              /////////////////////////
					         
					         }
					      

					      
					    /////set Selected MOD
					      var SelectedMOD = $(this).attr("ows_Requisition_x0020_MOD");
					      $('input[name="MODOptions"][value="'+SelectedMOD+'"]').prop('checked',true)
                        /////Get Selected Requirements Version  with function
                          var SelectedRequirementsVersion = $(this).attr("ows_Requirements_x0020_Version");
					      $('input[name="ProvisionCategory"][value="'+SelectedRequirementsVersion+'"]').prop('checked',true).click()
					    
                           /////set Selected Clause Types
                              var SelectedClause_String = $(this).attr("ows_Clause_x0020_Type");
                               if(SelectedClause_String !== undefined &&SelectedClause_String !== "" && Response_Determination == "Approve"){
                                 var SelectedClause_Types = SelectedClause_String.split(";");
                                $.each(SelectedClause_Types , function( index, value ) {////for each option found
                                   ///set value
                                   if (index % 2 === 0) {
                                     $('#ClauseTypeInput option[value=' + value.replace("#","").trim()+ ']').attr('selected', true);
                                   };////////
                                 
                                });
                              }////end for each option found

                             
                      //////////////////Set Applicable Technical Standard(s) 
                          var SPJSON, PrimaryObject, SubObject, x = "";
                          var SPJSONArry = $(this).attr("ows_Technical_x0020_Standard");
                          if( SPJSONArry.indexOf('{')>= 0 && Response_Determination == "Approve"){////end if objects exist
                                  SPJSON = JSON.parse(SPJSONArry);
								//////////Loop Standards
								for (PrimaryObject in SPJSON.Standard) {
								    /////Select Standard
								    var StandardID =SPJSON.Standard[PrimaryObject].ID;
								    var StandardChecked = SPJSON.Standard[PrimaryObject].checked;
								        if(StandardChecked == 'yes'){
								        $('#standard-'+StandardID+'cbx').prop('checked',true);
								        }       
								     ///////Loop Provisions
								    for (SubObject in SPJSON.Standard[PrimaryObject].Provision) {
								        /////Select Provisions
								        var ProvisionValue =SPJSON.Standard[PrimaryObject].Provision[SubObject];
								        $('input[parentcbx="standard-'+StandardID+'cbx"][value ="'+ProvisionValue +'"]').prop('checked',true);
								    }///////End Loop Provisions
								}//////////End Loop Standards
							}////end if objects exist
								//////////////////End Set Applicable Technical Standard(s) 
								 /////////////////set Approval Form
								 if(Response_Determination == 'Approve'){
								 $('#ReviewResponseInput_ApprovalComments').val(Response_Comments)
								 }else if(Response_Determination == 'Reject'){
								 $('#ReviewResponseInput_RejectionComments').val(Response_Comments)
								 }else if(Response_Determination == 'On Hold'){
								 $('#ReviewResponseInput_OnHoldComments').val(Response_Comments)
								 }

								 /////set Determination details
								           ////Response
								           var Response_DeterminationDisplay = 'In Progress';
								           if(Response_Determination == 'Approve'){
								             Response_DeterminationDisplay = 'Approved';
								           }else if(Response_Determination == 'Reject'){
								             Response_DeterminationDisplay = 'Rejected';
								           }else if(Response_Determination == 'On Hold'){
								             Response_DeterminationDisplay = 'On Hold';
								           };
								           DeterminationDetails['Response'] = Response_DeterminationDisplay;
								           ////Review Time
								           DeterminationDetails['ReviewTime'] = date_diff_indays(Response_Created, currentSystemDate )+' Day(s)';
                        
                        
                              
                                      
                                     ////set Recent Response
                                     if($(this).attr("ows_Recent_x0020_Response")!== undefined ){
                                     recentResponse($(this).attr("ows_Recent_x0020_Response"))
                                     }
                                     
                                     ///  set Analyst button
                                     var assignedAnalyst = $(this).attr("ows_Analysts");
                                     var assignedAnalystArry = [];
                                         assignedAnalystArry.push(assignedAnalyst);
                                         assignedAnalystfunc = "'"+assignedAnalystArry+"','"+ResponseID+"','508Form','"+DeterminationID+"','"+currentReQNumber+"'";
                                     $('.btn-Assign').attr('onclick','assignResponse('+assignedAnalystfunc+')');
                                       ///set analyst value
                                       if(assignedAnalyst !== undefined){
                                         var Analysts_Array = assignedAnalyst.split(";");
                                             DeterminationDetails['Analysts'] = '';
                                            $.each(Analysts_Array , function( index, value ) {
                                                
													   if (index % 2 === 0 && value !== ''){
													 
											            }else if(value !== ''){
											              var OptionValue = value;
                                                        if(OptionValue.indexOf('#') >= 0){OptionValue = OptionValue.substring(OptionValue.indexOf('#')+1)};
													      DeterminationDetails['Analysts'] += '</br><a class="AssignedAnalystEmail" href="mailto:'+OptionValue+'" >'+OptionValue+'</a>';
											            }
											  });
                                        };
                                        //////////////////////////////////////

                                     
                                       /////////////////////////////
                                       

   
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                    
                                    
                                      }
                                   })  
                    //////////End SpServcies Get List Items  OnHoldComments
                    ///load ck editors
                     CKEDITOR.replace( 'ReviewResponseInput_ApprovalComments' ).on('instanceReady',function(){
                     CKEDITOR.replace( 'ReviewResponseInput_RejectionComments' )
                            ///finshed loading 508 form
						        if(callback  !== undefined){ 
						          callback();
						        }
 
                     }); ////end load Approval Comments
                  
    
                
                  
                    ///////////set On Hold text editor
    //CKEDITOR.replace( 'ReviewResponseInput_OnHoldComments' );

        
 
 };//////////////////////////////////
////////////////////////////////
//////Enable Approval Type Options
  function enableApproval_Options(thisInput){
    var thisInput_Text = $('#'+thisInput+' option:selected').text();
    /////if New Contract Signature
      if(thisInput_Text == 'New Contract Signature'){
        $('#ClauseTypeContainer').collapse('show')
      }else{
        $('#ClauseTypeContainer').collapse('hide')
      }
    /////////////////
    
  };
  
 ///////////////////////// 
 /////////toggle EIT Cert Form
 function EITCertToggle(EITCbx){
     if($(EITCbx).is(':checked')){
         ///Enable EIT Cert Form 
            ///add required attribute
            $('.EIT-input').attr('aria-required','true');
            ///enable TextArea
            $('.EIT-input').prop('disabled',false);
            ///////////set text editor
        CKEDITOR.replace( 'EITStandards' );
        CKEDITOR.replace( 'EITSource' );
        CKEDITOR.replace( 'EITDetermine' );
         $('#EITForm-Div').collapse('show');

            
     }else{
            //////////remove text editor
            CKEDITOR.instances["EITStandards"].destroy();
            CKEDITOR.instances["EITSource"].destroy();
            CKEDITOR.instances["EITDetermine"].destroy();

           ///add required attribute
            $('.EIT-input').removeAttr('aria-required','true');
           /// remove error attributes and class
            $('.EIT-input').removeAttr('aria-invalid','true');
            $('.EIT-input').removeClass('has-error'); 
            $('.EITStandard-Label').removeClass('has-error'); 
            /// empty TextArea
             $('.EIT-input').val('');
            ///disable TextArea
            $('.EIT-input').prop('disabled',true);
             $('#EITForm-Div').collapse('hide');
            
     };
 //////////////////////////////////////////////////////
 
 };
 /////////////////////////////////////////////////////
  ////get and set Selectable options
 function setClauseSelections(targetInput,targetList ){
       ////empty dropdown
        $(targetInput +'> .Sp-Selectable').remove()
      /////get all Approval Types
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+ 
                             "<FieldRef Name='Instructions' />"+ 
                             "<FieldRef Name='Link' />"+                                                            
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: targetList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      
                                   //////set selectable options
                                   $(targetInput).append('<option instructions="'+$(this).attr("ows_Instructions")+'" Link="'+$(this).attr("ows_Link")+'" class="Sp-Selectable" value="'+$(this).attr("ows_ID")+'">'+$(this).attr("ows_Title")+'</option>');                                                                                                                                                                                                                                                                                                                               
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 
                    
                    
 }
 /////////////////////////////////////////////////
 ////////////set review form
 function Load508Form(loadStatus){
 /////resize form 
       //$('#wrapper').css( "overflow","auto" );
     // $('#content').css( "overflow","visible" );
    // $('#wrapper').css( "height","130px" );
    if(loadStatus == 'Done'){
  $('#full508Form').css('visibility', 'visible');
      ///collapse open containers
    $('.has-preload').addClass('collapse');
    
   ///remove loading spinner
    $('#Loading-Container').remove();
     /////resize form
   // $('#wrapper').css( "height","100%" );   
       
     }
 //////////////
 };
 //////////////////////////////////////
 //////////// set read only mode
 function readonly_508(formResponse){
 
    if(formResponse == 'Rejected'){
       //// show form actions
      $('.form508-action').show();
    
    }else {
   
       //// hide form actions
      $('.form508-action').hide();
		      /// hide Resonse select
		      if(formResponse == 'Approved'){
		       $('.formResponse-action').hide();
		      }

    }
 
 
 }
 ////////////////////////////////////////////////////
 /////function reset Determination response
 function resetDeterminationResponse(){
 
     /////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'Update',
                                ID:ResponseID ,
						        listName: "Determination Responses",
						        valuepairs:  [["Response", "" ],
											   ],
											
						        completefunc: function(xData, Status) {
						      /////////////////////////
							        if(Status == 'success'){	
								         ///send ready for review Alert and updates received alert
								             AlertResponseStatus = 'Ready for Review' ;
								             refreshTemplates();
								             saveAlert(AlertRejectUpdate.Subject,AlertRejectUpdate.Body,currentUserProfile.EMail);
								             saveAlert(AlertStatus.Subject,AlertStatus.ReviewBody,AlertAnalysts());

							             //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Response Form updates have been saved.'////Message
										         );
									   //////////////////////////
									  

							        }else{
							           //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										//////////////////////////////////////////////////         
							        

							        
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservices
 

 
 }
 ////////////////////////////////////////
//////////enable repsonse preview button
function enablePreview(preview_btn,previewResponseType){

      ////// Response Reject selected
   if(previewResponseType == 'Reject'){
       
      var DropdownValue =  $('#ReviewResponseInput_Rejecttion').val();
            if(DropdownValue !==""){
            ///enable preview button
                $(preview_btn).prop('disabled',false);;
            }else{
            ///disable preview button
               $(preview_btn).prop('disabled',true);;
            }
       
     }
      //////////////////
      ////// Response Approve selected
   if(previewResponseType == 'Approve'){
       
      var DropdownValue =  $('#ApprovalTypeInput').val();
            if(DropdownValue !==""){
            ///enable preview button
                $(preview_btn).prop('disabled',false);;
            }else{
            ///disable preview button
               $(preview_btn).prop('disabled',true);;
            }
       
     }
      //////////////////
     


}

/////////////////////////////////////////////
 
 
 
 
 
 