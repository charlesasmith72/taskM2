﻿///set dahsboard table variables
  var AllItem_Array =[];
  var AllItem_Rows ="";
  var Assignments_Rows ="";
  var MyRequest_Rows ="";
  /////response variables
  var ResponseArray_ID =[];
  var ResponseArray_Status =[];
  var ResponseArray_StatusChartItems =[];
  var ResponseArray_Response =[];
  ///assignment variables
  var ResponseArray_Analysts=[];
  var ResponseArray_AssignButtons=[];
  var ResponseArray_AssignStatus=[];
  var AssignedCount =0;
  var UnAssignedCount =0;
  var currentItemReQNumber = function(itemReQ){
     ///set current line item REQ Number
      var returnREQNumber =$('a[AssingnDetID = "'+itemReQ+'"]').attr('AssingnDetREQ');
      return returnREQNumber ;
  }
  

////////document ready
$(document).ready(function(){

/////get All items table
getAll_RequestData()
   ///create Tables
   createAllitmesTBL();
   createAssignmentsitmesTBL();
   createMyitmesTBL();
   
///// create Charts
  loadDoughnut();
  loadPie(); 
 


 
 ////set active panel
 $('.tablePanel-btn').click(function(){ 
 ////reset classes
  $('.tablePanel-btn').removeClass('active collapsed');
  ////make link active
      $(this).addClass('active');
 
 })
///////////////////////////////
 ////set dashboard permissions
if(AdminPermission == 'no' && AnalystPermission == 'no'){
   
   $('#MyRequests-btn').click();

}

////////////////////////
})/////////////

/////////////////////////////////////////////
///////load Chart
function loadDoughnut(){
//alert(ResponseArray_StatusChartItems)
var ApprovedCount = 0;
var RejectedCount = 0;
var InProgressCount = 0;
var WaitingCount = 0;
///set each value
$.each( ResponseArray_StatusChartItems , function( index, value ){

    if(value == 'Approved'){
       ApprovedCount += 1;
    }else if(value == 'Rejected'){
       RejectedCount += 1;
    }else if(value == 'Review In Progress'){
       InProgressCount += 1;
    }else if(value == 'Waiting for Signature'){
       WaitingCount += 1;
    };



});
////////////////////////////////////
 
$('#StatusChart-Container').empty().append(' <canvas id="StatusChart"  ></canvas>');


var ctx = $("#StatusChart");
var data = {
    labels: [
        ApprovedCount+" Approved",
        RejectedCount+" Rejected",
        InProgressCount+" Review In Progress",
        WaitingCount+" Waiting for Signature"
    ],
    datasets: [
        {   label: 'Current ',
            data: [ApprovedCount,RejectedCount, InProgressCount , WaitingCount ],
            backgroundColor: [
                "#4BC0C0",
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ],
            hoverBackgroundColor: [
                "#4BC0C0",
                "#FF6384",
                "#36A2EB",
                "#FFCE56"
            ]
        }]
};




var myDoughnutChart = new Chart(ctx, {
    type: 'bar',
    data: data,
    options: {
        animation:{
            animateScale:true
        },
        legend: {
            display: false
         },

    }
    ////////////////////////
});



};
///////////////////////////////////
/////////////////////////////////
function loadPie(){
 
$('#AssignedChart-Container').empty().append(' <canvas id="AssignedChart"  ></canvas>');

var ctx = $("#AssignedChart");
var data = {
    labels: [
        AssignedCount+" Assigned Request(s)",
        UnAssignedCount +" Unassigned Request(s)",
    ],
    datasets: [
        {
            data: [AssignedCount ,UnAssignedCount ],
            backgroundColor: [
                "#4BC0C0",
                "#FF6384"
            ],
            hoverBackgroundColor: [
                "#4BC0C0",
                "#FF6384"
            ]
        }]
};

 

var myDoughnutChart = new Chart(ctx, {
    type: 'pie',
    data: data,
    options: {
        animation:{
            animateScale:true
        }
    }
    ////////////////////////
});






/////////////
};
//////////////////////////////
////////////////get table
function setTableWgroup(tableID){
 
 
$(tableID).DataTable({

        "columnDefs": [

            { "visible": false, "targets": 1 }

        ],

        "order": [[ 1, 'asc' ]],

        "displayLength": 25,

        "drawCallback": function ( settings ) {

            var api = this.api();

            var rows = api.rows( {page:'current'} ).nodes();

            var last=null;

 

            api.column(1, {page:'current'} ).data().each( function ( group, i ) {

                if ( last !== group ) {

                    $(rows).eq( i ).before(

                        '<tr class="group"><td  colspan="8"><b style="color:#2c3e50">Conttract Number '+group+'</b></td></tr>'

                    );

 

                    last = group;

                }

            } );

        }

    } ); 
    
 
 
//////////////////////////////////////////
}////////////

////////////////get table
function setTable(tableID,sortCol,disabelcol){
 $(tableID).DataTable( {

        "order": [[ sortCol, "desc"]],
        "columnDefs": [{"orderable": false, "targets":disabelcol }]

    } ); 
   
 
//////////////////////////////////////////
}////////////
//////////////////////////////////////
////get All Responses
  function getAll_ResponseData(){
 

  //////reset arrays
  ResponseArray_ID =[];
  ResponseArray_Status =[];
  ResponseArray_Response =[];
  ResponseArray_Analysts=[];
  ResponseArray_AssignButtons =[];
  ResponseArray_AssignStatus =[];

  /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                            "<FieldRef Name='ID'/>"+ 
                            "<FieldRef Name='_x0035_08_x0020_Determination'/>"+
                            "<FieldRef Name='Response'/>"+
                            "<FieldRef Name='Approval_x0020_Type'/>"+ 
                            "<FieldRef Name='Rejection_x0020_Reason'/>"+ 
                            "<FieldRef Name='Rejection_x0020_Reason_x0020_Oth'/>"+
                            '<FieldRef Name="Analysts"/>'+                          
                            "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Determination Responses",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          //'<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var Response_ID = $(this).attr("ows_ID");
                                     var ResponseDetermination_ID = "";
	                                     if($(this).attr("ows__x0035_08_x0020_Determination")!== undefined){
	                                       ResponseDetermination_ID = $(this).attr("ows__x0035_08_x0020_Determination").substring($(this).attr("ows__x0035_08_x0020_Determination").indexOf('#')+1); 
	                                     };
	                                  var ResponseDetermination_Status= $(this).attr("ows_Response");
	                                  var ResponseDetermination_ApprovalType= "";
                                           if($(this).attr("ows_Approval_x0020_Type")!== undefined){
	                                       ResponseDetermination_ApprovalType= $(this).attr("ows_Approval_x0020_Type").substring($(this).attr("ows_Approval_x0020_Type").indexOf('#')+1); 
	                                     };
	                                   var ResponseDetermination_RejectionReason= "";
                                           if($(this).attr("ows_Rejection_x0020_Reason")!== undefined){
	                                       ResponseDetermination_RejectionReason= $(this).attr("ows_Rejection_x0020_Reason").substring($(this).attr("ows_Rejection_x0020_Reason").indexOf('#')+1); 
	                                          if(ResponseDetermination_RejectionReason == 'Other'){
	                                           ResponseDetermination_RejectionReason = $(this).attr("ows_Rejection_x0020_Reason_x0020_Oth");
	                                          };
	                                        };
                                      var ResponseDetermination_ResponseStatus="Waiting for Signature";
                                      var ResponseDetermination_Response = "";
                                          if(ResponseDetermination_Status == 'Approve'){
                                             ResponseDetermination_Response = ResponseDetermination_ApprovalType;
                                          }else if(ResponseDetermination_Status == 'Reject'){
                                             ResponseDetermination_Response = ResponseDetermination_RejectionReason;
                                          }
                                          ///  set Analyst button
                                     var assignedAnalyst = $(this).attr("ows_Analysts");
                                     var assignedAnalystArry = [];
                                         assignedAnalystArry.push(assignedAnalyst);
                                         assignedAnalystfunc = "'"+assignedAnalystArry+"','"+Response_ID+"','Dashboard','"+ ResponseDetermination_ID+"',currentItemReQNumber('"+ResponseDetermination_ID+"')";
                                         assignedAnalystfunc = 'assignResponse('+assignedAnalystfunc+')';
                                    var  assignedAnalystbutton ='<button class="btn btn-primary btn-md btn-Assign" style="margin-bottom: 10px;" onclick="'+assignedAnalystfunc+'" type="button"><i class="fa  fa-star" aria-hidden="true"></i> Assign Response</button>' 
     
                                    var  currentAnalyst = '';
                                    var  currentAnalystStatus = 'Unassigned';
                                         ///set analyst value
                                       if(assignedAnalyst !== undefined){
                                         var Analysts_Array = assignedAnalyst.split(";");
                                            $.each(Analysts_Array , function( index, value ) {
                                                
													   if (index % 2 === 0 && value !== ''){
													     // currentAnalyst  += '<a href="mailto:'+OptionValue+'" >'+OptionValue+'</a>';
											            }else if(value !== ''){
											              var OptionValue = value;
                                                        if(OptionValue.indexOf('#') >= 0){OptionValue = OptionValue.substring(OptionValue.indexOf('#')+1)};
													      currentAnalyst  += '<a href="mailto:'+OptionValue+'" >'+OptionValue+'</a><br/>';
											              currentAnalystStatus = 'Assigned'
											             }
											  });
                                        };
                                        //////////////////////////////////////

                                         ///set arrays
                                         ResponseArray_ID.push(ResponseDetermination_ID );
                                         ResponseArray_Status.push(ResponseDetermination_Status);
                                         ResponseArray_Response.push(ResponseDetermination_Response);
                                         ResponseArray_Analysts.push(currentAnalyst);
                                         ResponseArray_AssignButtons.push(assignedAnalystbutton);
                                         ResponseArray_AssignStatus.push(currentAnalystStatus);

                                       
                                          
                                     

                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all items
          
}
////////////////
////get All Request Table
  function getAll_RequestData(){
    ////get All Responses
  getAll_ResponseData()
  ////////////
    AllItem_Array =[];
    AllItem_Rows ="";
    Assignments_Rows ="";
    MyRequest_Rows ="";
     ///Reset assigned values
         AssignedCount =0;
         UnAssignedCount =0;
    
  
   /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                            "<FieldRef Name='ID'/>"+
                            '<FieldRef Name="Requisition_x0020_Number"/>'+
							'<FieldRef Name="Contract_x0020_Number"/>'+
							'<FieldRef Name="Created"/>'+
							'<FieldRef Name="Representative_x0020_Office"/>'+
							'<FieldRef Name="Representative_x0020_Email"/>'+
							'<FieldRef Name="Agency"/>'+
							'<FieldRef Name="Contract_x0020_Amount"/>'+
							'<FieldRef Name="Status"/>'+
							'<FieldRef Name="Display_Created"/>'+ 
							'<FieldRef Name="Author"/>'+	                      
                              "</ViewFields>"

                  ////////////////SPServices Get List Items Office Directory Contains
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "508 Determination",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          //'<Where><Eq><FieldRef Name="Category"/><Value Type="Text">'+categoryFIlter+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Created" Ascending="FALSE" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var Determination_ID = $(this).attr("ows_ID");
                                     var Determination_REQ = $(this).attr("ows_Requisition_x0020_Number");
                                     var Determination_Contract = $(this).attr("ows_Contract_x0020_Number");
                                     var Determination_Author = $(this).attr("ows_Author").substring($(this).attr("ows_Author").indexOf('#')+1)
                                     var Determination_Created = "";
                                     if($(this).attr("ows_Display_Created") !== undefined){
                                      Determination_Created = $(this).attr("ows_Display_Created").substring($(this).attr("ows_Display_Created").indexOf('#')+1);
                                      }
                                     var Determination_Office = $(this).attr("ows_Representative_x0020_Office");
                                         if($(this).attr("ows_Representative_x0020_Office")!== undefined ){
                                          Determination_Office = $(this).attr("ows_Representative_x0020_Office").substring($(this).attr("ows_Representative_x0020_Office").indexOf('#')+1); 
                                         };
                                     var Determination_RepEmail = $(this).attr("ows_Representative_x0020_Email");
                                     var Determination_Agency = $(this).attr("ows_Agency");
                                     var Determination_Amount = $(this).attr("ows_Contract_x0020_Amount");
                                         if($(this).attr("ows_Contract_x0020_Amount")!== undefined){
                                         Determination_Amount ='$'+ConvertCurresncy( $(this).attr("ows_Contract_x0020_Amount"));
                                         }
                                     var Determination_FormStatus = $(this).attr("ows_Status");
                                     var Determination_Status ="Waiting for Signature";
                                     var Determination_Deterimation =""; 
                                     var AssignAnalystButton ="";
                                     var AssignAnalyst ="";
                                     var AssignAnalystStatus ="";
                                

                                      /// set response values
								          if($.inArray(Determination_ID, ResponseArray_ID) !== -1){
								                             var ResponseIndex = ResponseArray_ID.indexOf(Determination_ID);  
								                                 Determination_Deterimation = ResponseArray_Response[ResponseIndex];       
								                                 //set Status
								                                 if(ResponseArray_Status[ResponseIndex] == 'Approve' &&  Determination_FormStatus == 'Review'){
								                                    Determination_Status = 'Approved';
								                                 }else if(ResponseArray_Status[ResponseIndex] == 'Reject' &&  Determination_FormStatus == 'Review'){
								                                    Determination_Status = 'Rejected';

								                                 }else {
								                                    Determination_Status = 'Review In Progress';

								                                 };
								                                 //set Analyst
								                                 AssignAnalyst = ResponseArray_Analysts[ResponseIndex];
								                                 //set Analyst Button
								                                   AssignAnalystButton  = ResponseArray_AssignButtons[ResponseIndex]
                                                                 //set Analyst Status
                                                                 AssignAnalystStatus = ResponseArray_AssignStatus[ResponseIndex];
								                                 ////////////////////////    
								                              }
							   var UrlParamStatus = Determination_FormStatus.toLowerCase();
							                                   
                              var Determination_REQLink = currentPageFileRef+"SiteAssets/508Determination.aspx?crumb="+UrlParamStatus+"&fid="+Determination_ID;

                                   
                                           ////set dashboard permissions for tables
                              if(AdminPermission == 'yes' && AnalystPermission == 'yes'){
                              ///// set status charts values
                                     ResponseArray_StatusChartItems.push(Determination_Status);
                                   ///////////set all items tables rows
                                   if(Determination_FormStatus !== 'Draft'){
                                   var AllItemTable_Row = '<tr>'+
                                                          '<th scope="row"><a href="'+Determination_REQLink+'">'+Determination_REQ+'</a></th>'+
                                                          '<td>'+Determination_Contract+'</td>'+
                                                          '<td>'+Determination_Created+'</td>'+
                                                          '<td>'+Determination_Office +'</td>'+
                                                          '<td><a href="mailto:'+Determination_RepEmail+'">'+Determination_RepEmail+'</a></td>'+
                                                          '<td>'+Determination_Agency+'</td>'+
                                                          '<td>'+Determination_Amount+'</td>'+
                                                          '<td>'+Determination_Status+' </td>'+
                                                          '<td>'+Determination_Deterimation+'</td>'+
                                                          '</tr>'
                                      AllItem_Rows += AllItemTable_Row; 
                                      }
                                       ///////////set Assignments items tables rows
                                       if(Determination_FormStatus !== 'Draft'){
                                      ///set assigned Stats
                                       if(AssignAnalystStatus == 'Assigned'){
                                         AssignedCount +=1;
                                         }else{
                                         UnAssignedCount +=1;
                                          }
                                          ///////////////////////////
                               
                                   
                                       
                                   var Assignments_Row = '<tr>'+
                                                          '<th scope="row"><a AssingnDetID="'+Determination_ID+'" AssingnDetREQ="'+Determination_REQ+'" href="'+Determination_REQLink+'">'+Determination_REQ+'</a></th>'+
                                                          '<td>'+Determination_Created+'</td>'+
                                                          '<td>'+Determination_Office +'</td>'+
                                                          '<td>'+AssignAnalystStatus+'</td>'+
                                                          '<td>'+AssignAnalyst+'</td>'+
                                                          '<td>'+AssignAnalystButton+'</td>'+
                                                          '</tr>'
							     
                                   Assignments_Rows += Assignments_Row;
                                      }
                             

                                      
                                      }////////end table permissions                    
                                      ///////////set MY items tables rows
                                      if(Determination_Author == currentUserProfile.EMail || Determination_RepEmail == currentUserProfile.EMail ){
                                   var MYItemTable_Row = '<tr>'+
                                                          '<th scope="row"><a href="'+Determination_REQLink+'">'+Determination_REQ+'</a></th>'+
                                                          '<td>'+Determination_Contract+'</td>'+
                                                          '<td>'+Determination_Created+'</td>'+
                                                          '<td>'+Determination_Office +'</td>'+
                                                          '<td><a href="mailto:'+Determination_RepEmail+'">'+Determination_RepEmail+'</a></td>'+
                                                          '<td>'+Determination_Agency+'</td>'+
                                                          '<td>'+Determination_Amount+'</td>'+
                                                          '<td>'+ Determination_Status+'</td>'+
                                                          '<td>'+Determination_Deterimation+'</td>'+
                                                          '</tr>'
							     
                                   MyRequest_Rows += MYItemTable_Row;
                                   
                                   
                                               ////set my chart data
                              if(AdminPermission == 'no' && AnalystPermission == 'no'){
                                   ///// set status charts values
                                     ResponseArray_StatusChartItems.push(Determination_Status);
                                   //set assigned Stats
                                       if(AssignAnalystStatus == 'Assigned'){
                                         AssignedCount +=1;
                                         }else{
                                         UnAssignedCount +=1;
                                          }
                                          ///////////////////////////

                                   }//////////////////end set my chart data
                                   
                                    }
							     
                                      

                                    
                                          
                                ///////////////////////////////////////////////////////////////////////                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all items

          
  
  };

//////////////////////////////////////////////
////////create all items Table
function createAllitmesTBL(){

var TableID = 'AllRequest-Table'
var TableHTML = '<table id="'+TableID+'" class=" table table-hover table-condensed "> '+
			'<thead> <tr> <th>Requisition Number</th><th>Contract</th> <th>Created</th> <th>Business Unit</th><th>Representative</th>  <th>Agency</th><th><span aria-hidden="true" >Est. Amount</span><span class="sr-only">Estimated Contract Amount</span></th><th>Status</th> <th>Response</th> </tr> </thead>'+ 
			AllItem_Rows+
			'<tbody>'+ 
			'</tbody> </table>'


/////empty previous table
   $('#AllRequest-Container').empty().append(TableHTML)
 ///set Datatable.js
     setTable('#AllRequest-Table',2);




}



///////////////////////////////////////////////////
////////create My items Table
function createMyitmesTBL(){

var TableID = 'MyRequests-Table'
var TableHTML = '<table id="'+TableID+'" class=" table table-hover table-condensed "> '+
			'<thead> <tr> <th>Requisition Number</th><th>Contract</th> <th>Created</th> <th>Business Unit</th><th>Representative</th>  <th>Agency</th><th><span aria-hidden="true" >Est. Amount</span><span class="sr-only">Estimated Contract Amount</span></th><th>Status</th> <th>Response</th> </tr> </thead>'+ 
			MyRequest_Rows+
			'<tbody>'+ 
			'</tbody> </table>'


/////empty previous table
   $('#MyRequests-Container').empty().append(TableHTML)
 ///set Datatable.js
     setTable('#MyRequests-Table',2);




}



///////////////////////////////////////////////////
////////create My items Table
function createAssignmentsitmesTBL(){

var TableID = 'Assignment-Table'
var TableHTML = '<table id="'+TableID+'" class=" table table-hover table-condensed "> '+
			'<thead> <tr> <th>Requisition Number</th> <th>Created</th> <th>Business Unit</th><th>Assignment Status</th> <th>Current Analysts</th><th><span class="sr-only">Manage Analysts buttons</span></th></tr> </thead> '+ 
			Assignments_Rows+
			'<tbody>'+ 
			'</tbody> </table>'


/////empty previous table
   $('#Assignment-Container').empty().append(TableHTML)
 ///set Datatable.js
     setTable('#Assignment-Table',1,5);




}



///////////////////////////////////////////////////
function refreshContent(){

/////get All items table
getAll_RequestData()
   ///create Tables
   createAllitmesTBL();
   createAssignmentsitmesTBL();
   createMyitmesTBL();
  ///// create Charts
  loadDoughnut();
  loadPie(); 
 
 

}


