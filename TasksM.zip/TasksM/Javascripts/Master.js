﻿////Global Variables
var currentPageLocationFullURL = window.location.href  ;
var currentPageFileRef = window.location.href.substring(0,window.location.href.lastIndexOf("SiteAssets"));  
var currentPageLocationName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/SiteAssets")+1);
var currentPageLocationTitle = $('title').html().substring($('title').html().lastIndexOf("|")+1).trim();
var currentPageQueryString = $().SPServices.SPGetQueryString();
var currentPageCrumb = currentPageQueryString["crumb"];
var currentUserProfile;
var currentSystemDate;
var selectableOffices =[];
var selectableOfficesValues =[];
var DeterminationID = currentPageQueryString["fid"];
var currentReQNumber;
var SelectableAttachmentTypes="";
var AttachedDocument_Links = [];
var SelectedAnalysts_ID =[];
var SelectedAnalysts_Emails =[];
var SelectedAnalysts_All =[];
var currentAnalyst_ItemIds = [];
var myAssignValue ='';
var OrignalAnalyst=[];
var NewAnalyst=[];  



 //////get ck editor Values
 var ckVal_Html = function(ckInput){///HTML
 ///////////DO Not use ID #
     var OriginalHtml = CKEDITOR.instances[ckInput].getData() ; 
     var SPSavebleHtml = OriginalHtml.replace(/</g,"&#60;").replace(/>/g,"&#62;");
  return SPSavebleHtml 
 
 };
 var ckVal_Text = function(ckInput){////Text
 ///////////DO Not use ID #
     var OriginalText = CKEDITOR.instances[ckInput].document.getBody().getText() ; 
  return OriginalText ; 
 
 };
 var ckVal_ConvertedBack = function(htmlValue){////Text

		 if(htmlValue !== undefined){
		     var newText = htmlValue.replace(/&#60;/g,"<").replace(/&#62;/g,">") ; 
		  return newText  ; 
		  }
 
 }

 

/////////////////// if(currentForm_Description!== undefined){currentForm_Description= currentForm_Description.replace(/&#60;/g,"<").replace(/&#62;/g,">")}
 

$(document).ready(function(){
 


//// get current user attributes
currentUserProfile= $().SPServices.SPGetCurrentUser({
	fieldNames: ["ID", "Name", "Title","FirstName","LastName","EMail","Office"],
	debug: false
});

////Set Navigation
setNavigation()

/////set current user Display
$('.currentUser-Display').html(currentUserProfile.Title)
/////set current Date
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd='0'+dd
} 

if(mm<10) {
    mm='0'+mm
} 

today = mm+'/'+dd+'/'+yyyy;

currentSystemDate = today
////////////////
////Query Offices 
 getOffices()
////Query Attachment Types
getSelectable_AttachmentTypes();


 

    getAnalystAssignment();
    
    ///set Pager Permssions
    setPermissions();
    
});///ENd Document ready

////Set Navigation
function setNavigation(){
///// set side navigation current link
$('#dock > .launcher > a').each( function( index, element ){
   if('SiteAssets/'+$( this ).attr('href').substring(0,$( this ).attr('href').lastIndexOf(".aspx")+5) == currentPageLocationName){
      $( this ).parent('li').addClass('active');
      
     }
}); 
///// set currentpage breadcrumb
if(currentPageCrumb == undefined ){
$('#breadcrumb').append('<li><a href="../'+currentPageLocationName+'" class="active">'+currentPageLocationTitle+'</a></li>')
}else{
///// set currentpage breadcrumb url parameter
if(currentPageCrumb.length == 0 ){currentPageCrumb = 'Current Page' } 
$('#breadcrumb').append('<li><a href="../'+currentPageLocationName+'">'+currentPageLocationTitle+'</a></li>')
$('#breadcrumb').append('<li><a id="brumb-current" href="'+currentPageLocationFullURL+'" class="active">'+currentPageCrumb+'</a></li>')
} 
///// set current user profile name
$('#mysite-navlink').html('<i class="fa fa-user" aria-hidden="true"></i> '+currentUserProfile.Title+' <span class="sr-only">SharePoint Mysite</span>')



}
/////////End set Navigation
/////////Set Signature Fields
function setSigFields(Sig_CBXButton){
  var SignatureBTN = $('#'+Sig_CBXButton).attr('for')
   ///If or Else Certified
  if ($('#'+Sig_CBXButton).is(':checked')) {
        ///Enable Button
          $('#'+SignatureBTN).prop('disabled', false);
  }else{
        ///Disable Button
        $('#'+SignatureBTN).prop('disabled', true);
  };

};
/////////End set Signature Fields
/////////Set Signature Fields
function signSigFields(Sig_Field){
   ///set User Name
   $('#'+Sig_Field+'-Name').val(currentUserProfile.FirstName+' '+currentUserProfile.LastName);
   ///set Signature
   var UserAcountName = currentUserProfile.Name
   $('#'+Sig_Field+'-UserName').val(UserAcountName.substring(UserAcountName.lastIndexOf('\\')+1));
   ///disable Check box
   $('#'+Sig_Field+'-cbx').prop('disabled', true);
   ///Hide Sign Button
   $('#'+Sig_Field+'-Btn').hide()
   ///Set Signature Status
   $('#'+Sig_Field+'-Status').html('<i class="fa fa-check" aria-hidden="true" ></i> Signed').addClass('badge-success')
   ///Set Signature Status Screen Reader
   $('#'+Sig_Field+'-StatusSR').html('Signed by '+currentUserProfile.FirstName+' '+currentUserProfile.LastName+' on '+currentSystemDate)
   ///save draft
   if(Sig_Field == "508Signature"){
    saveDraft('Sign') 
   }

};
/////////End set Signature Fields
//////////////

//////////Edit Document Properties
function editDocProperties( DodcExt,DocId,DocAtt){
      var docFileRef = $("a[attachmentID='"+DocId+"']").attr('href');
        var DocName= $("a[attachmentID='"+DocId+"']").attr('attachmentName');
        var doclib =  $("a[attachmentID='"+DocId+"']").attr('attachmentLibrary');

 var Modal_ID = 'DocuemntEdit-Modal';
 var Modal_Context= 'Attachment'
 var Modal_Title = 'Attachment Properties';
 var Modal_TitleIcon = '<i class="fa fa-wrench" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'
 var Modal_Body = Modal_Instructions+
                  '<form>'+
		             ' <fieldset>'+
		               '<div class="form-group">'+
					    '<label for="editDOCInput_Name"><span class="sr-only">Edit</span> Attachment Name</label>'+
					    '<div class="input-group" >'+
					    '<input type="text" disabled="disabled"  class="form-control" id="editDOCInput_Name" value="'+DocName+'" placeholder="Document Name"/>'+
					    '<div aria-hidden="true" class="input-group-addon">'+DodcExt+'</div>'+
					   '</div>'+
					  '</div>'+
					  '<div  class="form-group">'+
			           '<label for="editDOCInput_Type"><span class="sr-only">Edit</span> Attachment Type</label>'+
			           '<select   id="editDOCInput_Type" class="form-control">'+
			              '<option value ="" >Select a Attachment Type</option>'+
			              SelectableAttachmentTypes+
				       '</select>'+
						'</div>'+
						 
					  '<fieldset>'+
					'<form>'  
	//////Upload file
        	
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        '<button onclick="updateDocumentProps('+"'"+DocId+"'"+')" type="button" class="btn btn-success ">'+
			              'Save '+Modal_Context+' Edits'+
			             '</button> '+
			             '<button onclick="updateDocumentProps_Delete('+"'"+DocId+"'"+')"type="button" class="btn btn-danger ">'+
			              'Delete '+Modal_Context+
			             '</button>'+
        '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
        
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'

  //remove old modal
  $('#'+Modal_ID).remove()
  //append Modal to the Page Body
  $('body').append(DocPropertiesModal) ;
    //set default attachment type
  if( DocAtt!==undefined){
  
        $("#editDOCInput_Type").val(DocAtt)
  }   

  //show Modal
  $('#'+Modal_ID).modal('show')



}
///////End Edit Document Properties
//////Office Validation
function getOffices(){
   var needsRefresh = "No"
   selectableOffices =[];
   selectableOfficesValues =[];
   /////get all offices
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='Name' />"+ 
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Business Unit",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                     selectableOffices.push($(this).attr("ows_Name"));
                                     selectableOfficesValues.push($(this).attr("ows_ID"));
                                                   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all offices
                  
                    /////check each current user office
                    var currentUserOfficeArray = currentUserProfile.Office.split(',');
                        $.each(currentUserOfficeArray, function( index, value ) { 
                        var levelCount =index+1
                    /////If office is in array
                   if($.inArray(value.trim() , selectableOffices) == -1){
                 
                        //////Save new Office
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: "New",
						        listName: "Business Unit",
						        valuepairs: [["Title", "Business Unit"], ["Name",value.trim()],["Category",levelCount]],
						        completefunc: function(xData, Status) {
						          
						        }
						    });
                        //////End save new office SPservices
                          needsRefresh = "Yes"
                   }/////End if office is in array
			                   
                     });///End check each current user office
                   //if needs refreshed  
                   if(needsRefresh == "Yes"){
                     getOffices()
                   }

                         
 
}

/////////////////////////////////////
/////Get Selectable Office Business Unites
 function getBusinessUnitesOptions(UnitTarget){  
  $.each(selectableOffices, function( index, value ) { 
      //Set Selectable Options
      $(UnitTarget).append('<option value="'+selectableOfficesValues[index]+'">'+value+'</option>')
      
 
 });



}

/////////////////////////////////////////
////Create folder
function createFolder(newFolderName){
 
 /////Create Folder Case Attachment Documents
                        $().SPServices({
                                        operation: "UpdateListItems",
                                        async: false,
                                        listName: "Determination Attachments",
                                        batchCmd: "New",                        
			                            updates: "<Batch OnError='Continue' PreCalc='TRUE' ListVersion='0' >" +
				                                    "<Method ID='1' Cmd='New'>" +
				                                    "<Field Name='FSObjType'>1</Field>" +
				                                    "<Field Name='BaseName'>"+newFolderName+"</Field>" +
				                                    "</Method>" +
				                                    "</Batch>",
                                     completefunc: function(xData, Status) {
                                             //////If successful
                                           if(Status == 'success'){
                                           
                                          //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Determination Form updates have been saved.'////Message
										         );
									   //////////////////////////

                                           
                                              }else{
                                           //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										////////////////////////////////////////////////// 
                                                                                                 
                                                                                                 
                                                                                                 
                                             };
                                             //////End if successful

                                         }
        
                                   });
                                 /////////////////////////////////////////////////////////
 
 
}
///////////////////////////////////////////////////////////////////
//////Upload file
   function UploadFiles(){
    
      var DraftREQNumber ='$ '
 var Modal_ID = 'Upload-Modal';
 var Modal_Context= 'Upload'
 var Modal_Title = 'Upload a File';
 var Modal_TitleIcon = '<i class="fa fa-upload"" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'

 var Modal_Body = Modal_Instructions+
                  '<form>'+
		             ' <fieldset>'+
					  '<div  class="form-group">'+
			           '<label for="newDOCInput_Type"><span class="sr-only">Edit</span> Attachment Type</label>'+
			           '<select onchange="resetUploader('+"'newDOCInput_Type'"+')" iframewrap="'+Modal_ID+'Uploader" style="width:690px"   id="newDOCInput_Type" class="form-control">'+
			              '<option value ="" >Select a Attachment Type</option>'+
			              SelectableAttachmentTypes+
				       '</select>'+
						'</div>'+
						 '<div id="'+Modal_ID+'Uploader" ></div>'+
					  '<fieldset>'+
					'<form>'
 
                
		
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog  modal-lg" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
          '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(DocPropertiesModal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')

   
   }

///////////////////////////////////////////////////


////////close uploader modal
function closeModalUploader(){
  $('#Upload-Modal').modal('hide')
}
////////Uplodoad Successful
function UploadSucessful(updatedfolderID){
     //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your new Document has been Uploaded successfully.'////Message
										         );
									   //////////////////////////



 
///// refresh 
getAttachmentFiles(updatedfolderID)
 //// close uploader modal
   closeModalUploader()

}                                                                               
////// Get all selectable attachment Types
function getSelectable_AttachmentTypes(){
/////get all offices
SelectableAttachmentTypes = ""
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+
                              "<FieldRef Name='ABRV' />"+                                                            
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items  
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Attachment Types",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      var  AttType_ABRV =""
                                          if($(this).attr("ows_ABRV")!== undefined && $(this).attr("ows_ABRV")!== " "){
                                              AttType_ABRV ="("+$(this).attr("ows_ABRV")+")"
                                          }                                                                                                                                                                                                                                                                                                                           
                                     SelectableAttachmentTypes += '<option value="'+$(this).attr("ows_ID")+'">'+$(this).attr("ows_Title")+" "+AttType_ABRV+'</option>'
                                  
                                                   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get  Liist Items
 
 }////////////////////////////////                      
///////////////////////
/////Reset Uploader
function resetUploader(selectorUsed,attachmentLibraryattachmentLibrary,DeterminationFolderID){
var SelectAttachment_Value = $('#'+selectorUsed).val();
var IframeWrap = $('#'+selectorUsed).attr('iframewrap');
attachmentLibrary='Determination%20Attachments'
DeterminationFolderID = DeterminationID;
DeterminationFolder ="Determination"+DeterminationFolderID;

    ///// Remove/reset Iframe 
     $('#'+IframeWrap).empty()
if(SelectAttachment_Value !== "" && SelectAttachment_Value !== undefined ){//show iframe
    
    /////Append Iframe 
     $('#'+IframeWrap).append('<iframe width="100%"  style="height:200px;border:0px!important" src="Upload2010.aspx?libraryname='+attachmentLibrary+'&fname='+DeterminationFolder+'&attype='+SelectAttachment_Value+'"></iframe>')
    
    
  } 

}
///////////////////////////////////
///////get Attachment Documents

function getAttachmentFiles(DeterminationFolderID){ 
       
     //empty original files
     $('#AttachmentTable > tbody').empty()
      AttachedDocument_Links =[];                                                                                                                                                                            
    

     
         DocumentQuery = '<Query><Where><Contains><FieldRef Name="FileDirRef"/><Value Type="Text">Determination'+DeterminationFolderID+'</Value></Contains></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'
                
    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: 'Determination Attachments',
                                        CAMLViewFields: "<ViewFields><FieldRef Name='ID' /><FieldRef Name='Attachment_x0020_Type'/><FieldRef Name='Attachment_x0020_Type_x003a_Title'/><FieldRef Name='Attachment_x0020_Type_x003a_ABRV'/><FieldRef Name='LastMOD' /><FieldRef Name='FileDirRef' /><FieldRef Name='Created' /><FieldRef Name='_SourceUrl' /><FieldRef Name='_SourceUrl' /><FieldRef Name='FileLeafRef' /><FieldRef Name='ID' /><FieldRef Name='Author' /><FieldRef Name='FileDirRef' /><FieldRef Name='DocIcon' /><FieldRef Name='FileRef' /></ViewFields>",
                                        CAMLQuery:DocumentQuery ,
                                        CAMLQueryOptions: '<QueryOptions><ViewAttributes Scope="Recursive"/></QueryOptions>',
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                          var Document_ID = $(this).attr("ows_ID")
                                          var Document_Name =$(this).attr("ows_FileLeafRef").substring( $(this).attr("ows_FileLeafRef").indexOf('#')+1);
                                          var Document_URL = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1)+"/"+Document_Name;
                                          var DocumentLink = $(this).attr("ows_FileRef").substring( $(this).attr("ows_FileRef").indexOf('#')+1);
                                          var DocumentMOD =  $(this).attr("ows_LastMOD").substring( $(this).attr("ows_LastMOD").indexOf('#')+1);
                                          var Document_AttType = $(this).attr("ows_Attachment_x0020_Type_x003a_Title");
                                          var Document_AttID ="";
                                      
                                                                  /// Set attchment Type
                                                                    if(Document_AttType !== undefined ){///If attachment Type is not unidentified
                                                                               Document_AttType =  $(this).attr("ows_Attachment_x0020_Type_x003a_Title").substring( $(this).attr("ows_Attachment_x0020_Type_x003a_Title").indexOf('#')+1).trim();       
                                                                               Document_AttID = $(this).attr("ows_Attachment_x0020_Type_x003a_Title").substring(0, $(this).attr("ows_Attachment_x0020_Type_x003a_Title").indexOf(';')).trim(); 
                                                                     }else{
                                                                               Document_AttType ="Other";
                                                                               
                                                                     }
                                                                                  /// Set attchment Abbreviation
											                                          var Document_AttTypeABRV ="";
											                                              if($(this).attr("ows_Attachment_x0020_Type_x003a_ABRV") !== undefined ){///If Abbreviation is not unidentified
											                                                   Document_AttTypeABRV = $(this).attr("ows_Attachment_x0020_Type_x003a_ABRV").substring( $(this).attr("ows_Attachment_x0020_Type_x003a_ABRV").indexOf('#')+1).trim();
											                                                   if(Document_AttTypeABRV.length > 0 && Document_AttTypeABRV !="None" ){/// Abbreviation in () if present
											                                                       Document_AttTypeABRV = "("+Document_AttTypeABRV+")"
											                                                  }
											                                              }/// End set attchment Abbreviation
                                                                 //////////////////////////////////                 
						                                          
						 
                                ///set document icon
                                    var docicon = $(this).attr("ows_DocIcon");  
                                         if(docicon.indexOf('do') > -1){//Word Document
                                               docicon='fa-file-word-o'                                                                                                                              
                                         }else if(docicon.indexOf('pdf') > -1){
                                                docicon='fa-file-pdf-o'                                                                                                                            
                                         }else if(docicon.indexOf('xl') > -1){
                                                  docicon='fa-file-excel-o'                 
                                         }else if(docicon.indexOf('ppt') > -1){
                                                  docicon='fa-file-powerpoint-o'                    
                                         }else if(docicon.indexOf('jpg') > -1 || docicon.indexOf('bmp') > -1 || docicon.indexOf('png') > -1 || docicon.indexOf('gif') > -1 || docicon.indexOf('tiff') > -1){
                                                  docicon='fa-file-image-o'                    
                                         }else{
                                              docicon = 'fa-file-o'
                                           }
                                    /////////////////////////////////////
                                    var docEditFunc = "'"+"."+$(this).attr("ows_DocIcon")+"'"+","+"'"+Document_ID+"'"+","+"'"+Document_AttID+"'"

                                       ////add Table row
                                       $('#AttachmentTable > tbody').append(
                                            '<tr >'+
                                            '<td scope="row"  ><i aria-hidden="true" class="fa '+docicon+'" ></i> <a attachmentID="'+Document_ID+'" attachmentName="'+Document_Name+'" attachmentLibrary="Determination Attachments" href="'+Document_URL+'">'+Document_Name+'</a></td>'+
                                            '<td>'+Document_AttType+' <span aria-hidden="true">'+Document_AttTypeABRV+'</span></td>'+
                                            '<td><span class="sr-only">Last Modified on </span>'+DocumentMOD+'</td>'+
                                            '<td><button type="button" class="btn btn-default input-Adminpermissions input-Analystpermissions input-Creatorpermissions form508-action" onclick="editDocProperties('+docEditFunc+')"  >'+
                                            '<span  aria-hidden="true" >...</span><span class="sr-only">'+Document_Name+' Attachment Options</span></button></td>'+
                                            '</tr>'
                                       
                                       )
                                      ///set document Parameters\
                                                                                                                         
                                        
                                       ///add to documents list
                                        AttachedDocument_Links.push('<a  href="'+Document_URL+'">'+Document_Name+'</a>')
                                       /////////////////////////
                                       

                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  


 
}
//////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
function updateDocumentProps(DocId){
   var docFileRef = $("a[attachmentID='"+DocId+"']").attr('href');
        var DocName= $("a[attachmentID='"+DocId+"']").attr('attachmentName');
        var doclib =  $("a[attachmentID='"+DocId+"']").attr('attachmentLibrary');

  ////remove edit modal
      $('#DocuemntEdit-Modal').modal('hide')
 var Modal_ID = 'DocEdit';
 var Modal_Context= 'Alert'
 var Modal_Title = 'Confirm';
 var Modal_TitleIcon = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>';
 var Modal_Body = '<p>'+
 'Are you sure you want to save these changes for '+DocName+'? </p>'+
 '</p>'+
 '<button type="button" onclick="postDocumentPorps('+"'"+DocId+"'"+')" class="btn btn-success btn-sm" >Yes <span class="sr-only">Save</span></button> '+
 '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">No <span class="sr-only">Do not save</span></button>'
                
		
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog modal-sm" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(DocPropertiesModal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')


}
///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
function updateDocumentProps_Delete(DocId){
        var docFileRef = $("a[attachmentID='"+DocId+"']").attr('href');
        var DocName= $("a[attachmentID='"+DocId+"']").attr('attachmentName');
        var doclib =  $("a[attachmentID='"+DocId+"']").attr('attachmentLibrary');
        
        

  ////remove edit modal
      $('#DocuemntEdit-Modal').modal('hide')
 var Modal_ID = 'DocDelete';
 var Modal_Context= 'Alert'
 var Modal_Title = 'Confirm';
 var Modal_TitleIcon = '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>';
 var Modal_Body = '<p>'+
 'Are you sure you want to Delete '+DocName+'? </p>'+
 '</p>'+
 '<button type="button" onclick="deleteAttachment('+DocId+')" class="btn btn-danger btn-sm" >Yes <span class="sr-only">Delete</span></button> '+
 '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">No <span class="sr-only">Do not Delete</span></button>'
                
		
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog modal-sm" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
  $('#'+Modal_ID).remove()
  $('body').append(DocPropertiesModal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')


}
///////////////////////////////////
////////Update Document Properties fields
function postDocumentPorps(DocId){
 
 
       var editAttachment = $('#editDOCInput_Type').val()
    	  
             
                        //////Save new Office
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: "Update",
						        listName: "Determination Attachments",
						        ID:DocId,
						        valuepairs:  [["Attachment_x0020_Type", editAttachment],
											     ],
											
						        completefunc: function(xData, Status) {
							        if(Status == 'success'){
							          //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Document updates have been saved.'////Message
										         );
									   //////////////////////////

							          ///// refresh 
                                     getAttachmentFiles(DeterminationID)

							          
							          $('#DocEdit').modal('hide')
							         
							          
							          
                                   ///////////////////////////////////
							        }else{
							         //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										////////////////////////////////////////////////// /

							        
							        }
						          
						        }
						    });
                        //////End save new office SPservices


 


}


//////////////////////////
////delete document
   function deleteAttachment(docid){
        var docFileRef = $("a[attachmentID='"+docid+"']").attr('href');
        var docname = $("a[attachmentID='"+docid+"']").attr('attachmentName');
        var doclib =  $("a[attachmentID='"+docid+"']").attr('attachmentLibrary');
        
                       $().SPServices({
                      operation: "UpdateListItems",
                      listName: doclib,
                      updates: "<Batch OnError='Continue'><Method ID='1' Cmd='Delete'><Field Name='ID'>"+docid+"</Field><Field Name='FileRef'>"+docFileRef +"</Field></Method></Batch>",
                          completefunc: function(xData, Status) {
                          
                             if(Status == 'success'){
                                          //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Deleted!',////Bold Alert
										         'The Document '+docname+' has been successfully deleted.'////Message
										         );
									   //////////////////////////

                                     getAttachmentFiles(DeterminationID)

							          
							          $('#DocDelete').modal('hide')
							         
                                                                                                                                                                                               

                                      }else{
							         //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										////////////////////////////////////////////////// /

							        
							        }
    
                              ////////////////////////                                                                                                                                                                                                                                                                    





                          }

                });

 
   
   }
///////////////////////////////////////////////////////////////////////////////
///////////Delete this folder
function deleteFolder(){ 
 var FoldertoFind =  'Determination'+DeterminationID 
 var QueryList = "Determination Attachments"
 var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+
                              "<FieldRef Name='FileRef' />"+ 
                              "<FieldRef Name='FileDirRef' />"+ 
                              "<FieldRef Name='FileLeafRef' />"+                                                            
                              "</ViewFields>"
 ////////////////SPServices Get List Items  
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: QueryList ,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><Where><Contains><FieldRef Name="FileLeafRef"/><Value Type="Text">'+FoldertoFind+'</Value></Contains></Where><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                     var foundFolder_ID =$(this).attr("ows_ID");
                                     var foundFolder_Ref =$(this).attr("ows_FileDirRef");
                                     var foundFolder_Name =$(this).attr("ows_FileLeafRef");
                                     ////////////////////////////////////////////////
                                     ///////Delte this Folder
                                     if(foundFolder_Ref!==undefined){
                                     foundFolder_Ref = foundFolder_Ref.substring(foundFolder_Ref.indexOf('#')+1)+"/";
                                     foundFolder_Name = foundFolder_Name.substring(foundFolder_Name.indexOf('#')+1);
                                   //  alert(foundFolder_Name)

                                      //////Delete Folder SPservices         
						                       $().SPServices({
						                      operation: "UpdateListItems",
						                      listName: QueryList,
						                      updates: "<Batch OnError='Continue'>"+
						                      "<Method ID='1' Cmd='Delete'>"+
						                      "<Field Name='ID'>"+foundFolder_ID+"</Field>"+
						                      "<Field Name='FileRef'>"+foundFolder_Ref+foundFolder_Name+"</Field>"+
						                      "</Method></Batch>",
						                          completefunc: function(xData, Status) {
						                          
						                             if(Status == 'success'){
						                                      alert('deleted')                                                                                                                                             
						
						                                      }    
						            //////////////////////// End Delete Folder SPservices                                                                                                                                                                                                                                                                   

                          }
                       });
////////////////////////////////////////

                                     
                                   
                                     
                                     }
                                     ///////////////////////////////////////
                                          
                                                               
                                    })
                                  }
                               })  
                    //////////End SpServcies get  Liist Items 











}
//////////////////////////////////////////
/////////Vuclan alerts
function newAlert(msg_Container,msg_Theme,msg_Action,msg_Txt){//
if(msg_Theme== 'validation'){
   msg_Theme = 'danger danger-validation'
}

var msg_HTML =' <div class="alert alert-'+msg_Theme+' alert-dismissible" role="alert">'+
  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
  '<strong>'+msg_Action+'</strong> '+msg_Txt+
'</div>'


/////post ALert
$(msg_Container).append(msg_HTML)




}/////
////////////////////////////////////////////////////////
 ////get and set Selectable options
 function setSelections(targetInput,targetList ){
       ////empty dropdown
        $(targetInput +'> .Sp-Selectable').remove()
      /////get all Approval Types
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: targetList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      
                                   //////set selectable options
                                   $(targetInput).append('<option class="Sp-Selectable" value="'+$(this).attr("ows_ID")+'">'+$(this).attr("ows_Title")+'</option>');                                                                                                                                                                                                                                                                                                                               
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 
                    
                    
 }
 /////////////////////////////////////////////////
//////////////////////
/////Cancel Refresh Link
function refreshPage(){
    
     ///reomve extra parameters
      if(window.location.href.indexOf('#') >= 0){
       ///Redirect Page
       var redirectLink = window.location.href.substring(0,window.location.href.indexOf('#'))      
         window.location.href = redirectLink 
         
      }else{
       ///Redirect Page      
       window.location.href = window.location.href
      }
  // 

};
/////////////////////// 
//////differnce in days
var date_diff_indays = function(date1, date2) {
dt1 = new Date(date1);
dt2 = new Date(date2);
return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate()) ) /(1000 * 60 * 60 * 24));
}
////////////////////////////////
var ConvertCurresncy = function(inputValue){
   if(inputValue !== undefined){////convert to number than currensy
     var num = Number(inputValue);
           var n=num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
             inputValue = n
           }else{///if no value present
             inputValue = ""
           }
           return inputValue




}
////////////////////////////////////////////////////////////////
///////// get Analysts
  function getAnalystAssignment(){
    
    currentAnalyst_ItemIds =[];
    currentAnalyst = "No"
 
        /////get List Items
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                              "<FieldRef Name='ID' />"+ 
                               "<FieldRef Name='Analysts' />"+ 
                                "<FieldRef Name='_x0035_08_x0020_Determination' />"+                                                         
                              "</ViewFields>"
   
 
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "Determination Responses",
                               CAMLViewFields:Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where><Contains><FieldRef Name="Analysts"/><Value Type="Text">'+currentUserProfile.EMail+'</Value></Contains></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                                          '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                currentAnalyst_ItemIds.push($(this).attr("ows_ID"))
                            

 
///////////////////////////////////////////   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get List Items

   
  
  };
////////////////////////////////////////////////////

////////////Assign Response
  function assignResponse(SelectedArry,ResponseItemID,AssignMode,ResponseDeterminationItemID,ResponseReqNumber){
   
      var SelectMe = "assignMe()"
      var RemoveMe = "removeMe()" ; 
          OrignalAnalyst=[];
         
       ResponseID = ResponseItemID;                         
       DeterminationID = ResponseDeterminationItemID;
       currentReQNumber =ResponseReqNumber;
      
       
 
  var Modal_ID = 'AssignResponse-Modal';
 var Modal_Context= 'Assign'
 var Modal_Title = 'Assign Analysts';
 var Modal_TitleIcon = '<i class="fa fa-users" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'
				
var  Modal_Body	=Modal_Instructions+'<div class="form-group" >'+
			   '<label for="AnalystsSelectInput">Select Analysts to Assign</label>'+
			   	 '<select  class="form-control input-Adminpermissions" id="AnalystsSelectInput" aria-describedby="#AnalystsSelectInputthelpBlock" style="max-width: 850px;height: 100%;" multiple="multiple"   >'+
			     '</select>'+
			     ' <span class="help-block" id="AnalystsSelectInputhelpBlock">Hold '+
				'down the control (ctrl) button to select multiple options</span>'+
			  '<button type="button" id="btn-adduser" class="btn btn-md btn-primary input-Analystpermissions"  onclick="'+SelectMe+'" ><i class="fa fa-user-plus" aria-hidden="true"></i> Add Me <span  class="sr-only">to the assigned Analysts list</span></button> '+
              '<button type="button" id="btn-removeuser" style="display:none" class="btn btn-md btn-danger input-Analystpermissions" onclick="'+RemoveMe+'" ><i class="fa fa-user-times" aria-hidden="true"></i> Remove Me <span  class="sr-only">from the assigned Analysts list</span></button>'+
			  '</div>'+
			  '<label>Assigned Analysts</label>'+
			  ' <ul class="list-group" id="AnalystsList" style="list-style:none">'+
				 '</ul>'
				 
			  
			  
	
 var Modal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog  modal-lg" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div id="'+Modal_ID+'Html" class="modal-body">'+
        Modal_Body+
        '<div id="AssignUser-Alerts"></div>'+
      '</div>'+
      '<div class="modal-footer">'+
          '<button onclick="SaveAnalysts('+"'"+ResponseItemID+"','"+AssignMode+"'"+')" type="button" class="btn btn-success ">'+
			              'Save Analysts'+
			             '</button> '+
          '<button type="button" class="btn  btn-default" data-dismiss="modal">Close</button>'+
          

      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove modal
  $('#'+Modal_ID).remove()
  $('body').append(Modal) ;
  
  //get values
  setSelections_Analysts('#AnalystsSelectInput','Analysts' );
    ///////parse array
     /////set Selected Analysts Type
                              var SelectedAnalysts_String = SelectedArry;
                               if(SelectedAnalysts_String !== undefined &&SelectedAnalysts_String !== "" ){
                                 var SelectedAnalysts_Types = SelectedAnalysts_String.split(";");
                                $.each(SelectedAnalysts_Types , function( index, value ) {////for each option found
                                   ///set value
                                   if (index % 2 === 0) {
                                      $('#AnalystsSelectInput option[value=' + value.replace("#","").trim()+ ']').attr('selected', true);
                                   }else{
                                  
                                  // $('#AnalystsList').append('<li class="list-group-item">'+value.replace("#","")+'</li>')
                                                                         
                                  };////////
                                 ////////////
                                });
                              }////end for each option found
                              //set each selected option
                               $('#AnalystsSelectInput option:selected').each(function(Index) {
							        $('#AnalystsList').append('<li id="assignedUser'+$(this).val()+'" class="list-group-item">'+$(this).text()+'</li>');
                                        ///taggole add and remove me button
                                        OrignalAnalyst.push( $(this).text().trim());
                                        if($(this).text().trim() == currentUserProfile.EMail){
                                           $('#btn-adduser').hide();
                                           $('#btn-removeuser').show();
                                        }
							    });
							    
   //set permissions
   enableUsers()
  //show Modal
  $('#'+Modal_ID).modal('show')
  
  }
/////////////////////////////////////////
//// save Analysts
  function SaveAnalysts(SaveFor,AssignMode){
     /////set Analysts
  var SelectedAnalysts = "";
  var SelectedAnalystsTxt = "";
      NewAnalyst =[];
      $('#AnalystsSelectInput option:selected').each(function(Index) {
        if(Index == 0){
          SelectedAnalysts += $(this).val()+';#'+$(this).val() ;
          SelectedAnalystsTxt += '</br><a class="AssignedAnalystEmail" href="mailto:'+$(this).text()+'" >'+$(this).text()+'</a>';
          NewAnalyst.push($(this).text());
        }else{
          SelectedAnalysts += ';#'+$(this).val()+';#'+$(this).val() ;
          SelectedAnalystsTxt += '</br><a class="AssignedAnalystEmail" href="mailto:'+$(this).text()+'" >'+$(this).text()+'</a>';
          NewAnalyst.push($(this).text());
        }
        
    });
    

     //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'Update',
                                ID:SaveFor,
						        listName: "Determination Responses",
						        valuepairs:  [["Analysts", SelectedAnalysts  ]],
											
						        completefunc: function(xData, Status) {
						      /////////////////////////
							        if(Status == 'success'){	
								      /////send alert to new Analysts
									 $.each(NewAnalyst, function( key, value ) {
										 			 /////if Analyst is new
										 			 if ($.inArray(value , OrignalAnalyst) != -1)
															{
															  // found it
															}else{
															
															  refreshTemplates();
															  saveAlert(AlertAssignedAnalyst.Subject ,AlertAssignedAnalyst.Body, value )
															
															};
															///////////////////
										
											});

							             //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Saved!',////Bold Alert
										         'Your Analyst updates have been saved.'////Message
										         );
									   //////////////////////////
									  if(AssignMode == '508Form'){
									  ///set Analysts
									  var assignedAnalystfunc = "'"+SelectedAnalysts+"','"+SaveFor+"','508Form'";
									   $('.btn-Assign').attr('onclick','assignResponse('+assignedAnalystfunc+')');
									  $('.Analysts-Value').html(SelectedAnalystsTxt);
									  }else if('Dashboard'){
									   refreshContent()
									  }

							        }else{
							           //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error saving your changes.'////Message
										         )
										//////////////////////////////////////////////////         
							        }

							        
							        
						        }
						    });
                        //////End save SPservices
                        //hide Modal
  $('#AssignResponse-Modal').modal('hide')
  };////////////////
//////////////////////////////////////////////////////
///// add me from assigned list
function assignMe(){

 var emailuserValue= $("#AnalystsSelectInput option[email="+"'"+currentUserProfile.EMail+"'"+"]").val();
 if($("#AnalystsSelectInput option[value="+"'"+emailuserValue+"'"+"]").length > 0){
  $("#AnalystsSelectInput option[value="+"'"+emailuserValue+"'"+"]").attr('selected', true);
  $('#AnalystsList').append('<li id="assignedUser'+emailuserValue+'" class="list-group-item">'+currentUserProfile.EMail+'</li>');
   $('#btn-adduser').hide();
  $('#btn-removeuser').show();

  }else{
   //////////Post Vulcan Alert	         
	newAlert('#AssignUser-Alerts',////Location
	         'danger',////Theme
	         'Error!',////Bold Alert
	         'You are not a selectable Analyst. Please contact an Administrator'////Message
	         )
	//////////////////////////////////////////////////   
  }



}

//////////////////////////////////
///// reomve me form assigned list
function removeMe(){
 var emailuserValue= $("#AnalystsSelectInput option[email="+"'"+currentUserProfile.EMail+"'"+"]").val();
 if($("#AnalystsSelectInput option[value="+"'"+emailuserValue+"'"+"]").length > 0){
  $("#AnalystsSelectInput option[value="+"'"+emailuserValue+"'"+"]").attr('selected', false);
  $('#assignedUser'+emailuserValue).remove();
  $('#btn-adduser').show();
  $('#btn-removeuser').hide();
  
  }else{
   //////////Post Vulcan Alert	         
	newAlert('#AssignUser-Alerts',////Location
	         'danger',////Theme
	         'Error!',////Bold Alert
	         'You are not a selectable Analyst. Please contact an Administrator'////Message
	         )
	//////////////////////////////////////////////////   
  }


}

//////////////////////////////////

 ////get and set Selectable options
 function setSelections_Analysts(targetInput,targetList ){
       ////empty dropdown
        $(targetInput +'> .Sp-Selectable').remove()
      /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: targetList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                    
                                   //////set selectable options
                                   $(targetInput).append('<option class="Sp-Selectable" email="'+$(this).attr("ows_Title")+'" value="'+$(this).attr("ows_ID")+'">'+$(this).attr("ows_Title")+'</option>');                                                                                                                                                                                                                                                                                                                               
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 
                    
                    
 }
 /////////////////////////////////////////////////
////////////////
////  toggle instructions
function toggleinstructions(targerbtn){
       var targetstatus = $(targerbtn).attr('btn-status');
       if(targetstatus == 'on' ){
      $(targerbtn).html('Less Instructions').attr('btn-status','off');
      
      }else if(targetstatus == 'off'){
      $(targerbtn).html('More Instructions').attr('btn-status','on');
      
      }
    
};

/////////////////////////////////////////////////////////////




