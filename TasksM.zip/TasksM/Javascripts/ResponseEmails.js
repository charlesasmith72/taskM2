﻿  var message_Body ="";
  var message_Subject ="";
  var ResponseToEmail ="";
  var ResponseEmails =[];
  var RecentLog ="";
  var allResponseEmails =[];
////////////////////
 $(document).ready(function(){

      
      
/////Correct Email Formatting
 //  
  // $('body').on('change','.Email-Input',function(){
    //   var InputID = $(this).attr('id');
     //  if(InputID !== undefined){
     //   setEmailFormat(InputID );
      //  }
       /////////////
 //  })
///////////////////////////////
        

});

/////get Response Html
function getResponseTemp(tempID,QueryList){
        ////reset Variables
          message_Body ="";
          message_Subject="";
          ///set To: Email
         $('.ResponseToEmail').val(ResponseToEmail)

     if(QueryList !== 'On Hold'){
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+
                             "<FieldRef Name='Body' />"+
                             "<FieldRef Name='Subject' />"+                                                          
                              "</ViewFields>"
                  ////////////////SPServices Get List Items  
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName:QueryList, 
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where><Eq><FieldRef Name="ID"/><Value Type="Text">'+tempID+'</Value></Eq></Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                         message_Subject =$(this).attr("ows_Subject"); 
                                         message_Body = $(this).attr("ows_Body");                                   
                                    ////////////////////////////////                                   
                                    })
                                      }
                                   })  
                    //////////End SpServcies get  List Items
                    }
                    ///replace Place Holders
                    ///REQ Number placeholder
                       if(message_Subject.indexOf('Req#Placeholder')>=0){
                          message_Subject = message_Subject.replace('Req#Placeholder',currentReQNumber) 
                        
                       }
                    
                    ///date placeholder
                       if(message_Subject.indexOf('DatePlaceHolder')>=0){
                          message_Subject = message_Subject.replace('DatePlaceHolder',currentSystemDate) 
                        
                       }
                    
                    /////set Response Builder
                    if(QueryList == "Approval Types" ){
                       //set Subject
                         $('#ReviewResponseInput_Subject').val(message_Subject);
                       // set Email Template
                         $('#ReviewResponseInput_Body').html(message_Body);  
                         
                         ///make div editable
                        //  $('#ReviewResponseInput_Body').attr("contenteditable","true" )
                        // 
                        // 
                         
  
                    }else if(QueryList == "Rejection Reasons" ){ 
                      //set Subject
                        $('#RejectResponseInput_Subject').val(message_Subject);
                        // set Email TemplateRejectResponseInput_Body
                         $('#RejectResponseInput_Body').html(message_Body);  


                    }else if(QueryList == "On Hold" ){
                      //set Subject
                        message_Subject = 'On Hold'

                    }                   
                    
                    ///////////////////////////////
                     
                    
};
//////////////////////////////////////////////////

//////Preview
   function previewResponse(response_Form,response_To,response_CC,response_Subject,response_Comments,response_Body,response_Caluses,response_Standards){
    	   
      response_Body = response_Body;
         
       ////get selected Clauses
    	    var selectedClauses="";
    	 if(response_Caluses !== undefined && $('#ApprovalTypeInput').val()== '1'){ ///for each selected
	      $("#"+response_Caluses+" > option:selected").each(function() {
	      selectedClauses +='<li style=" padding-bottom:5px"><a href="'+$(this).attr('link')+'">'+this.text+'</a> - '+$(this).attr('instructions')+'</li>';
			   // alert(this.text + ' ' + this.value+ ' ' + $(this).attr('link')+ ' ' + $(this).attr('instructions'));
			});
		};//////////////////////
        //////Get Tech Standards
          var selectedTechStandards = "";
          

		if(response_Standards !== undefined){ ///for each selected
	      $(".TechStandard-cbx").each(function() {
	         ///// Set Main Standard
	         var MainProvision_ID = $(this).attr('id');
	         var MainProvision = "<li><b>"+$(this).attr('stanardnum')+" - "+$(this).attr('stanarddesc')+"</b>"
             var CheckProvisions="<ul><li>" ;
             var showMainProvision="No";
                 ///set checked sub standards
                    $('input[parentcbx="'+MainProvision_ID+'"]:checked').each(function() {
                       CheckProvisions += '<u><b>X</b></u>('+$(this).val()+') ';
                       showMainProvision="Yes";
                     }); 
	               ///add to list
	               if(showMainProvision == "Yes"){
	               selectedTechStandards += MainProvision+CheckProvisions+'</li></ul></li>';
	               }
			});
		};//////////////////////
						        
								        

								   
    
 var Modal_ID = 'Response-Modal';
 var Modal_Context= 'Preview'
 var Modal_Title = 'Email Preview';
 var Modal_TitleIcon = '<i class="fa fa-envelope" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'
				
	

 var Modal_Body = response_Body;
	var detrminLink =currentPageLocationFullURL				
///link # 
 if(detrminLink.indexOf('#')>= 0 ){
  detrminLink  =window.location.href.substring(0,window.location.href.lastIndexOf("#"));
  };
  
 
 var sendFunc = "'"+response_Subject+"','"+response_To+"','"+response_CC+"',"+'$('+"'#"+Modal_ID+"Html'"+').html()';              
		
 var Modal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog  modal-lg" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div id="'+Modal_ID+'Html" class="modal-body">'+
      '<h1>'+response_Subject+'</h1>'+
              '<p><i>Please do not reply to this email. We are unable to respond to emails sent to this address. For immediate answers to your questions, contact the IRAP team by emailing us at <a href="mailto:508.requisition.review@irs.gov" >*508 Requisition Review</a>.</p>'+
      '<a href="'+detrminLink+'" style="font-size: 24px;" >View 508 Determination Form</a></i>'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
      '<button type="button" class="btn btn-success" onclick="sendResponse('+sendFunc+')" >Send Response</button>'+
          '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove modal
  $('#'+Modal_ID).remove()
  $('body').append(Modal) ;
    	//////replace Comments Place Holder
	 if(response_Body.indexOf('Main-PlaceHolder') >= 0){

	     ///remove placeholder well
	     $('#'+Modal_ID).find('.Main-PlaceHolder').removeClass('well').html(
	     
	     ' <ul style="list-style:lower-alpha">'+
 '<li>At a minimum, others may apply, the following required 508 provisions must be <span style="background-color:yellow"><u><b>ADDED:</b></u></span>'+
 '<ul style="list-style:none">'+selectedTechStandards+'</ul>'+
 '</li>'+
 '<li>All required provisions must be <span style="background-color:yellow"><u><b>individually selected</b></u></span> (X) <u><b>Example:</b></u>'+
' <ul style="padding-top:5px; padding-bottom:10px;list-style:none"><li> <u><b> X </b></u>1194.31, Functional Performance Criteria. <u><b>X</b></u>(a) <u><b>X</b></u>(b) <u><b>X</b></u>(c) <u><b>X</b></u>(d) <u><b>X</b></u>(e) <u><b>X</b></u>(f) </li></ul>'+
 '</li>'+
 '<li>The applicable Section 508 provisions should be included in the solicitation. The applicable clauses for your requisition can be found here:'+
 '<ul style=" padding-bottom:10px" >'+
 '<li style=" padding-bottom:5px"><a href="http://awss.web.irs.gov/Procurement/policy/section508_clauses.shtml">http://awss.web.irs.gov/Procurement/policy/section508_clauses.shtml</a></li>'+
 selectedClauses+
 '</ul>'+
 '</li>'+
' </ul>'

	     
	     );

        

	  }
///////////////////////////////////	  

  
  	//////replace Comments Place Holder
	if(	response_Body.indexOf('Comments-PlaceHolder') >= 0){
	     var convertComments = ckVal_ConvertedBack(response_Comments);
	     ///remove placeholder well
	     $('#'+Modal_ID).find('.Comments-PlaceHolder').removeClass('well').html('')
	     if(convertComments !== ''){///add comment html
	     $('#'+Modal_ID).find('.Comments-PlaceHolder').html('<p><span lang="en-us"><u><font face="Arial" size="4">Comments from the assigned Analyst</font></u></span></p>'+convertComments+'<br>');
	      }
	  }
	  ////add document attachments
	  var ResponseAttachments ='<p id="AttachedDocument-Header"><span lang="en-us"><u><font face="Arial" size="4">'+currentReQNumber+' Documents</font></u></span></p><ul id="AttachedDocument-Container"></ul>';
	$(ResponseAttachments  ).insertAfter( $('#'+Modal_ID).find('.Comments-PlaceHolder'));
	 $.each(AttachedDocument_Links,function( index, value ) {
	 $('#'+Modal_ID).find('#AttachedDocument-Container').append('<li>'+value+'</li>')
	 
		
		});

	  
	   if(response_Body.indexOf('<') < 0){
	   var convertComments = ckVal_ConvertedBack(response_Comments);
	    $('#'+Modal_ID).find('.modal-body').html(
	       /////add body and text
	        '<h1>'+response_Subject+'</h1>'+
	       '<p><span lang="en-us"><u><font face="Arial" size="4">Comments from the assigned Analyst</font></u></span></p>'+
	        convertComments +
	       '<p><span lang="en-us"><b><font face="Arial" size="4">508 Program Office (IRAP)</font></b></span><br><span lang="en-us"><font face="Arial" size="4">IRAP Website: </font></span><a href="http://irap.web.irs.gov/"><span lang="en-us"><u></u><u><font color="#0000ff" face="Arial" size="4">http://irap.web.irs.gov</font></u></span></a><span lang="en-us"><font face="Arial" size="4"> </font></span><br><span lang="en-us"><font face="Arial" size="4">Reply to: *508 Requisition Review</font></span></p>'
	    
	    
	    )
	    /////add 
	  }
	  
     /////////////
     
     ///Set Req Number Placeholder 
      if(response_Body.indexOf('REQNUmber-PlaceHolder') >= 0){
         	     ///remove placeholder label style udate Html value
	     $('#'+Modal_ID).find('.REQNUmber-PlaceHolder').removeClass('label label-default').html('requisition '+currentReQNumber)
      
      }
      
      ///Set Date Placeholder 
      if(response_Body.indexOf('Date-PlaceHolder') >= 0){
         	     ///remove placeholder label style udate Html value
	     $('#'+Modal_ID).find('.Date-PlaceHolder').removeClass('label label-default').html(currentSystemDate )
      
      }
      
      ///Set Contract Placeholder 
      if(response_Body.indexOf('Contract-PlaceHolder') >= 0 && $('#ContractInput').val()!== undefined){
         	     ///remove placeholder label style udate Html value
	     $('#'+Modal_ID).find('.Contract-PlaceHolder').removeClass('label label-default').html($('#ContractInput').val())
      
      }
      


      
      
      ///Set Estimated Amount Placeholder 
      if(response_Body.indexOf('Amount-PlaceHolder') >= 0 && $('#RepresentativeAmountInput').val() !== undefined){
          // var num = Number($('#RepresentativeAmountInput').val());
           //var n=num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
           
          var EstimatedCost ='$'+ConvertCurresncy($('#RepresentativeAmountInput').val())
         	     ///remove placeholder label style udate Html value
	     $('#'+Modal_ID).find('.Amount-PlaceHolder').removeClass('label label-default').html(EstimatedCost)
      
      }
	

	

	    
	     
    	 

	
  
  
  
  //show Modal
  $('#'+Modal_ID).modal('show')
    
   
   }
/////////////////////////////////////////////
////////Send Response
  function sendResponse(EmailSubject,EmailTo,EmailCC,EmailBody){
             
 EmailBody = EmailBody.replace(/</g,"&#60;").replace(/>/g,"&#62;");
 
 
       //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'New',
						        listName: "Response Log",
						        valuepairs:  [["Title", EmailSubject],
						                      ["To",EmailTo],
						                      ["CC",EmailCC],
						                      ["Body",EmailBody],
						                      ["Response",ResponseID],
						                      ["Determination",DeterminationID ],
											],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        		  var newID = $(xData.responseXML).SPFilterNode("z:row").attr("ows_ID");
							        		  RecentLog = newID ;				        
							          openResponseIframe(newID);
							          saveEmailAddress(EmailCC)
                                      
							        }else{
							        //////////Post Vulcan Alert	         
										newAlert('#Form-Alerts',////Location
										         'danger',////Theme
										         'Error!',////Bold Alert
										         'There was an error Sending your Response.'////Message
										         )
										//////////////////////////////////////////////////         
							        
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservices

  
  
  
  }


///////////////////////////////////////////////////////////////
function updateHtml(LogID){
 //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'Update',
						        ID:LogID,
						        listName: "Response Log",
						        valuepairs:  [["Body", "Determination Form"],
											],
											
						        completefunc: function(xData, Status) {
						      
							        
						
						        }
						    });
                        //////End save SPservices






}

////////////////////////////////////////////////////////////////
/////Open Iframe  
function openResponseIframe(logID){
 
   //remove old ifrsme
   $('#convertHtml').remove();
  /////append to page
   $('#maincontent').append(
   
    '<div style="display:none" aria-hidden="true" id="convertHtml" >'+
    '<iframe src="RichTextConvert_2010.aspx?logid='+logID+'" ></iframe>'+
    
    '</div>'
   
   )

}
////////////////////////////////
 function closePreview(){
 
         ///close Modal
           $('#Response-Modal').modal('hide')
                       }

function ResponseSucessful(){ 
                      //////////Post Vulcan Alert
							          newAlert('#Form-Alerts',////Location
										         'success',////Theme
										         'Sent!',////Bold Alert
										         'Your Response has been sent.'////Message
										         );
									   ////////////////////////// 
									   saveResponse('Update')                                                                                
                closePreview()       
                           }   


////////////////////////////////////////
//get emails
function getEmails(){
   
       /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: 'Emails',
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      
                                   //////set selectable options
                                  ResponseEmails.push($(this).attr("ows_Title"));                                                                                                                                                                                                                                                                                                                               
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
  ///////////                  //////////End SpServcies Get List Items

  
///////set Auto complete 
   $( function() {

    var availableTags = ResponseEmails ;

    function split( val ) {

      return val.split(';' );

    }

    function extractLast( term ) {

      return split( term ).pop();

    }

 

    $( ".Email-Input" )

      // don't navigate away from the field on tab when selecting an item

      .on( "keydown", function( event ) {

        if ( event.keyCode === $.ui.keyCode.TAB &&

            $( this ).autocomplete( "instance" ).menu.active ) {

          event.preventDefault();

        }

      })

      .autocomplete({

        minLength: 0,

        source: function( request, response ) {

          // delegate back to autocomplete, but extract the last term

          response( $.ui.autocomplete.filter(

            availableTags, extractLast( request.term ) ) );

        },

        focus: function() {

          // prevent value inserted on focus

          return false;

        },

        select: function( event, ui ) {

          var terms = split( this.value );

          // remove the current input

          terms.pop();

          // add the selected item

          terms.push( ui.item.value );

          // add placeholder to get the comma-and-space at the end

          terms.push( "" );

          this.value = terms.join( ";" );

          return false;

        }

      });

  } );
///////end set Auto complete 


};
////////////////////////////////////
///format Emais
function setEmailFormat(emailInput){
  var InputValue = $("#"+emailInput).val();
      InputValue = InputValue.trim().replace(/,/g,";");
      // $("#"+emailInput).val(InputValue)  
};
////////////////////////////////
////save emails
function saveEmailAddress(newEmails){

   newEmails = newEmails.trim().replace(/,/g,"").split(';');
 ///save each email address
 $.each(newEmails, function( index, value ) {
  var emailtoSave = value 
 


 if(emailtoSave.indexOf('@') > 0 && emailtoSave !== ""){//if @ present

    //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'New',
						        listName: "Emails",
						        valuepairs:  [["Title", emailtoSave ],
											],
											
						        completefunc: function(xData, Status) {
						      
							     
							        
							        
						          
						        }
						    });
                        //////End save SPservices

       }//End if @ present
});
/////////////////End each save


};
////////////////////////////////////
//////////////Edit Template
function editTemp(ButtonStatus,editableDiv,EditTempBtn){

      if(ButtonStatus == 'On'){
     /////turn on CK Edit
     $('#'+editableDiv).attr("contenteditable","true")
      CKEDITOR.inline(editableDiv);
      var currentVariables = "Off','"+editableDiv+"','"+EditTempBtn
      //////update edit button
      $('#'+EditTempBtn).html('Done Editing').attr('onclick',"editTemp('"+currentVariables+"')")
      }else{ 
         /////turn off CK Edit
     $('#'+editableDiv).attr("contenteditable","false")
     CKEDITOR.disableAutoInline = true;
     CKEDITOR.instances[editableDiv].destroy(true);
      var currentVariables = "On','"+editableDiv+"','"+EditTempBtn
      //////update edit button
      $('#'+EditTempBtn).html('Edit Template').attr('onclick',"editTemp('"+currentVariables+"')")

      
      }



}
//////////////////////////////////////////////
////show recent response
function recentResponse(recentResponseID){
   
   ///set variables
   var RecentHtml ="";
   if(recentResponseID.indexOf('#') > 0){
      ///
     recentResponseID = recentResponseID.substring(recentResponseID.indexOf('#')+1);
     
     //reset approval select
    /// $('#ReviewResponseInput').val('');
    /// $('#ApprovalForm').collapse('hide');
   ///  $('#RejectForm').collapse('hide');
    ///  $('#OnHoldForm').collapse('hide');
   }
   var responceIndex = 0;
   ////empty Outbox
    $('#responseOutbox').empty();
   /////get all items
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+
                             "<FieldRef Name='Body' />"+
                             "<FieldRef Name='Created' />"+
                             "<FieldRef Name='Response' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: 'Response Log',
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                               '<Where><Eq><FieldRef Name="Response"/><Value Type="Text">'+ResponseID+'</Value></Eq></Where>'+
                               '<OrderBy><FieldRef Name="ID" Ascending="False" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      ////set Outbox
                                      $('#responseOutbox').append('<li class="list-group-item"><a role="button"  class="link-btn" onclick="showResponse('+"'"+responceIndex+"'"+')">'+$(this).attr("ows_Title")+'</a></li>');
                                      allResponseEmails.push($(this).attr("ows_Body"));
                                       
                                       //////set  Html
                                       if(recentResponseID == $(this).attr("ows_ID")){
                                       $('#previousResponse-Contatiner').show();
                                 RecentHtml = '<label ><span  style="color: rgb(51, 122, 183);">Response Email </span>'+$(this).attr("ows_Created")+'</label>'+$(this).attr("ows_Body");                                                                                                                                                                                                                                                                                                                               
                                 } 
                                 responceIndex += 1;
                                  //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
  ///////////                  //////////End SpServcies Get List Items


   ////////show Recent Response

    $('#previousResponse-Contatiner').html(RecentHtml);
    
    

}
/////////////////////////////////////////////
function showResponse(responseShow){

var Modal_ID = 'SentEmail-Modal';
 var Modal_Context= 'Preview'
 var Modal_Title = 'Sent Response Email';
 var Modal_TitleIcon = '<i class="fa fa-envelope" aria-hidden="true"></i>';
 var Modal_Instructions ='<div class="alert alert-warning" role="alert">'+
				'<i class="fa fa-info-circle" aria-hidden="true"></i>'+
				'<span class="sr-only">Instructions</span> '+
				'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do '+
				'eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut '+
				'enim ad minim veniam, quis nostrud exercitation ullamco laboris'+ 
				'nisi ut aliquip ex ea commodo consequat '+
				'</div>'
				
var  Modal_Body	=allResponseEmails[responseShow];
	
 var Modal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog  modal-lg" role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> '+Modal_TitleIcon+' '+Modal_Title+'</h2>'+
     ' </div>'+
      '<div id="'+Modal_ID+'Html" class="modal-body">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
     
          '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>'+
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove modal
  $('#'+Modal_ID).remove()
  $('body').append(Modal) ;
  //show Modal
  $('#'+Modal_ID).modal('show')
    


       
}
