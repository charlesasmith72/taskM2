﻿var PageLocationPath =  window.location.href;
var PageQueryString = $().SPServices.SPGetQueryString();
var attachmentType_Param = PageQueryString["attype"];

$(document).ready(function(){
  ////check page location
   if(PageLocationPath.indexOf('Forms/EditForm.aspx') >= 0 ){////If edit form
        ////Set upload html 
         setUploadEditForm();
     }



});//End Document ready
/////////////
 

/////////Set upload html 
function setUploadEditForm(){
  if(attachmentType_Param !== undefined){///set Attachment Type
  $("select[title='Attachment Type']").val(attachmentType_Param)
  }
  ///Trigger save button
   $("input[value='Save']").click()
}
/////////////////////