﻿var AdminPermission = 'no';
var AnalystPermission ='no';
var CreatedByPermission ='no';

///////set Permissions
function setPermissions(){

//////////////////////////////////////////////////////////////////
////get SHarePoint Groups
   $().SPServices({
     operation: "GetGroupCollectionFromUser",
     userLoginName: $().SPServices.SPGetCurrentUser(),
     async: false,
     completefunc: function(xData, Status) {
     
        ///////if a member of the Admin group
        if($(xData.responseXML).find("Group[Name$='Vulcan Admins']").length == 1)
        {
        
           ///set admin permissions
           AdminPermission ='yes'
       
        };
       //////////////// 
 
      }
   });
////////////////////////////////////////////////////////////////////////
    /////get all Analysts
    
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: 'Analysts',
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                               '<Where><Eq><FieldRef Name="Title"/><Value Type="Text">'+currentUserProfile.EMail+'</Value></Eq></Where>'+
                               '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy>'+
                               '</Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                    
                                   //////set Analyst Permissions
                                           AnalystPermission ='yes';                                                                                                                                                                                                                                                                                                                      
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 

                                    
///////////////////////////////////////////////////////////////////////////////


 
//////enable Permissions
enableUsers();

};

function enableUsers(){

 ////disable permissioned inputs
 $('.input-enableskip').removeClass('input-Adminpermissions').removeClass('input-Analystpermissions').removeClass('input-Creatorpermissions');
 $('.input-Adminpermissions,.input-Analystpermissions,.input-Creatorpermissions').prop('disabled',true);
 ///hide permssioned elemnt
 $('.show-element-enableskip').removeClass('show-element-Adminpermissions').removeClass('show-element-Analystpermissions').removeClass('show-element-Creatorpermissions');
 $('.show-element-Adminpermissions,.show-element-Analystpermissions,.show-element-Creatorpermissions').hide();

/////enable Admin
if(AdminPermission == 'yes'){
  ////enable permissioned inputs
 $('.input-Adminpermissions').prop('disabled',false);
  ///show permssioned elemnt
 $('.show-element-Adminpermissions').show();



}
/////enable Analyst
if(AnalystPermission == 'yes'){

   ////enable permissioned inputs
  $('.input-Analystpermissions').prop('disabled',false);
   ///show permssioned elemnt
 $('.show-element-Analystpermissions').show();



}
 

/////enable CreatedBy
if(CreatedByPermission == 'yes'){

   ////enable permissioned inputs
    $('.input-Creatorpermissions').prop('disabled',false);
   ///show permssioned elemnt
   $('.show-element-Creatorpermissions').show();



}
 
////////////////////

}//////////////////////////////
