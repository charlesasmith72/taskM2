﻿////Global Variables
var currentPageLocationFullURL = window.location.href  ;
var currentPageFileRef = window.location.href.substring(0,window.location.href.lastIndexOf("SiteAssets"));  
var currentPageLocationName = window.location.pathname.substring(window.location.pathname.lastIndexOf("/SiteAssets")+1);
var currentPageLocationTitle = $('title').html().substring($('title').html().lastIndexOf("|")+1).trim();
var currentPageQueryString = $().SPServices.SPGetQueryString();
var currentPageCrumb = currentPageQueryString["crumb"];
var currentUserProfile;
var currentSystemDate;
var selectableOffices =[];
var selectableOfficesValues =[];
var DeterminationID = currentPageQueryString["fid"];
var currentReQNumber;
var SelectableAttachmentTypes="";
var AttachedDocument_Links = [];
var SelectedAnalysts_ID =[];
var SelectedAnalysts_Emails =[];
var SelectedAnalysts_All =[];
var currentAnalyst_ItemIds = [];
var myAssignValue ='';
var OrignalAnalyst=[];
var NewAnalyst=[];  



 //////get ck editor Values
 var ckVal_Html = function(ckInput){///HTML
 ///////////DO Not use ID #
     var OriginalHtml = CKEDITOR.instances[ckInput].getData() ; 
     var SPSavebleHtml = OriginalHtml.replace(/</g,"&#60;").replace(/>/g,"&#62;");
  return SPSavebleHtml 
 
 };
 var ckVal_Text = function(ckInput){////Text
 ///////////DO Not use ID #
     var OriginalText = CKEDITOR.instances[ckInput].document.getBody().getText() ; 
  return OriginalText ; 
 
 };
 var ckVal_ConvertedBack = function(htmlValue){////Text

		 if(htmlValue !== undefined){
		     var newText = htmlValue.replace(/&#60;/g,"<").replace(/&#62;/g,">") ; 
		  return newText  ; 
		  }
 
 }

 

/////////////////// if(currentForm_Description!== undefined){currentForm_Description= currentForm_Description.replace(/&#60;/g,"<").replace(/&#62;/g,">")}
 

$(document).ready(function(){
 


//// get current user attributes
currentUserProfile= $().SPServices.SPGetCurrentUser({
	fieldNames: ["ID", "Name", "Title","FirstName","LastName","EMail","Office"],
	debug: false
});

////Set Navigation
setNavigation()

/////set current user Display
$('.currentUser-Display').html(currentUserProfile.Title)
/////set current Date
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd='0'+dd
} 

if(mm<10) {
    mm='0'+mm
} 

today = mm+'/'+dd+'/'+yyyy;

currentSystemDate = today
////////////////


    
});///ENd Document ready

////Set Navigation
function setNavigation(){
///// set side navigation current link
$('#dock > .launcher > a').each( function( index, element ){
   if('SiteAssets/'+$( this ).attr('href').substring(0,$( this ).attr('href').lastIndexOf(".aspx")+5) == currentPageLocationName){
      $( this ).parent('li').addClass('active');
      
     }
}); 
///// set currentpage breadcrumb
$('#breadcrumbpage-link').html(currentPageLocationTitle)
///// set current user profile name
$('#mysite-navlink').html('<i class="fa fa-user" aria-hidden="true"></i> '+currentUserProfile.Title+' <span class="sr-only">SharePoint Mysite</span>')



}
/////////End set Navigation
